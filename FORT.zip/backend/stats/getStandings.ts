type Params = { season_id: number; group_id?: number }

export default async function (req: { params: Params; user: User }) {
  const { season_id, group_id } = req.params

  const result = await retoolDb.query(`
    WITH p AS (SELECT $1::int as sid, $2::int as gid),
    match_results AS (
      SELECT m.home_team_id as team_id,
        CASE WHEN m.home_score > m.away_score THEN 3
             WHEN m.home_score = m.away_score THEN 1
             ELSE 0 END as points,
        CASE WHEN m.home_score > m.away_score THEN 1 ELSE 0 END as won,
        CASE WHEN m.home_score = m.away_score THEN 1 ELSE 0 END as drawn,
        CASE WHEN m.home_score < m.away_score THEN 1 ELSE 0 END as lost,
        m.home_score as goals_for, m.away_score as goals_against
      FROM matches m, p
      WHERE m.status = 'finished' AND m.season_id = p.sid
      UNION ALL
      SELECT m.away_team_id as team_id,
        CASE WHEN m.away_score > m.home_score THEN 3
             WHEN m.away_score = m.home_score THEN 1
             ELSE 0 END as points,
        CASE WHEN m.away_score > m.home_score THEN 1 ELSE 0 END as won,
        CASE WHEN m.away_score = m.home_score THEN 1 ELSE 0 END as drawn,
        CASE WHEN m.away_score < m.home_score THEN 1 ELSE 0 END as lost,
        m.away_score as goals_for, m.home_score as goals_against
      FROM matches m, p
      WHERE m.status = 'finished' AND m.season_id = p.sid
    )
    SELECT t.id, t.name, t.logo_url, t.primary_color, t.secondary_color,
      COUNT(mr.team_id)::int as played,
      COALESCE(SUM(mr.won), 0)::int as won,
      COALESCE(SUM(mr.drawn), 0)::int as drawn,
      COALESCE(SUM(mr.lost), 0)::int as lost,
      COALESCE(SUM(mr.goals_for), 0)::int as goals_for,
      COALESCE(SUM(mr.goals_against), 0)::int as goals_against,
      COALESCE(SUM(mr.goals_for - mr.goals_against), 0)::int as goal_diff,
      COALESCE(SUM(mr.points), 0)::int as points
    FROM teams t
    CROSS JOIN p
    JOIN team_seasons ts ON ts.team_id = t.id AND ts.season_id = p.sid
    LEFT JOIN match_results mr ON mr.team_id = t.id
    WHERE (p.gid IS NULL OR ts.group_id = p.gid)
    GROUP BY t.id, t.name, t.logo_url, t.primary_color, t.secondary_color
    ORDER BY points DESC, goal_diff DESC, goals_for DESC
  `, [season_id, group_id ?? null])
  return result.data
}
