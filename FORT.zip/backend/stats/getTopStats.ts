type Params = { season_id: number }

export default async function (req: { params: Params; user: User }) {
  const result = await retoolDb.query(`
    WITH sid AS (SELECT $1::int as val),
    season_events AS (
      SELECT me.player_id, me.event_type
      FROM match_events me
      JOIN matches m ON m.id = me.match_id
      CROSS JOIN sid
      WHERE m.season_id = sid.val
    )
    SELECT
      p.id, p.name, p.nickname, p.photo_url, p.position, p.number,
      t.name as team_name, t.primary_color as team_color, t.logo_url as team_logo,
      COUNT(CASE WHEN se.event_type = 'goal' THEN 1 END)::int as goals,
      COUNT(CASE WHEN se.event_type = 'assist' THEN 1 END)::int as assists,
      COUNT(CASE WHEN se.event_type = 'yellow_card' THEN 1 END)::int as yellow_cards,
      COUNT(CASE WHEN se.event_type = 'red_card' THEN 1 END)::int as red_cards
    FROM players p
    JOIN teams t ON t.id = p.team_id
    CROSS JOIN sid
    JOIN team_seasons ts ON ts.team_id = t.id AND ts.season_id = sid.val
    LEFT JOIN season_events se ON se.player_id = p.id
    GROUP BY p.id, p.name, p.nickname, p.photo_url, p.position, p.number,
      t.name, t.primary_color, t.logo_url
    HAVING COUNT(CASE WHEN se.event_type = 'goal' THEN 1 END) > 0
      OR COUNT(CASE WHEN se.event_type = 'assist' THEN 1 END) > 0
      OR COUNT(CASE WHEN se.event_type = 'yellow_card' THEN 1 END) > 0
      OR COUNT(CASE WHEN se.event_type = 'red_card' THEN 1 END) > 0
    ORDER BY goals DESC, assists DESC
  `, [req.params.season_id])
  return result.data
}
