type Params = { match_id: number }

export default async function (req: { params: Params; user: User }) {
  const { match_id } = req.params

  const matchRes = await retoolDb.query(`
    SELECT m.*,
      ht.name as home_team_name, ht.logo_url as home_team_logo, ht.primary_color as home_color,
      at.name as away_team_name, at.logo_url as away_team_logo, at.primary_color as away_color,
      u.username as referee_name
    FROM matches m
    JOIN teams ht ON ht.id = m.home_team_id
    JOIN teams at ON at.id = m.away_team_id
    LEFT JOIN users u ON u.id = m.referee_id
    WHERE m.id = $1
  `, [match_id])

  const eventsRes = await retoolDb.query(`
    SELECT me.*, p.name as player_name, p.nickname, p.number, p.team_id,
      t.name as team_name, t.primary_color as team_color
    FROM match_events me
    JOIN players p ON p.id = me.player_id
    JOIN teams t ON t.id = p.team_id
    WHERE me.match_id = $1
    ORDER BY me.minute NULLS LAST, me.created_at
  `, [match_id])

  const lineupRes = await retoolDb.query(`
    SELECT ml.*, p.name as player_name, p.nickname, p.number, p.position, p.photo_url, p.team_id
    FROM match_lineups ml
    JOIN players p ON p.id = ml.player_id
    WHERE ml.match_id = $1
    ORDER BY ml.type, p.number
  `, [match_id])

  const subsRes = await retoolDb.query(`
    SELECT ms.*,
      po.name as player_out_name, po.number as player_out_number, po.team_id,
      pi.name as player_in_name, pi.number as player_in_number
    FROM match_substitutions ms
    JOIN players po ON po.id = ms.player_out_id
    JOIN players pi ON pi.id = ms.player_in_id
    WHERE ms.match_id = $1
    ORDER BY ms.minute
  `, [match_id])

  return {
    match: matchRes.data[0] ?? null,
    events: eventsRes.data,
    lineup: lineupRes.data,
    substitutions: subsRes.data,
  }
}
