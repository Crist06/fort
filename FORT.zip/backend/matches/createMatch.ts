type Params = {
  season_id: number
  home_team_id: number
  away_team_id: number
  match_date?: string
  round?: number
  location?: string
  group_id?: number
  referee_id?: number
}

export default async function (req: { params: Params; user: User }) {
  const caller = await retoolDb.query<{ role: string }>(
    `SELECT role FROM users WHERE email = $1`, [req.user.email]
  )
  const role = caller.data[0]?.role
  if (!['administrator', 'captain', 'referee'].includes(role ?? '')) throw new Error('No autorizado')

  const result = await retoolDb.query(`
    INSERT INTO matches (season_id, home_team_id, away_team_id, match_date, round, location, group_id, referee_id)
    VALUES ($1, $2, $3, $4, $5, $6, $7, $8) RETURNING *
  `, [req.params.season_id, req.params.home_team_id, req.params.away_team_id,
      req.params.match_date ?? null, req.params.round ?? null,
      req.params.location ?? null, req.params.group_id ?? null, req.params.referee_id ?? null])
  return result.data[0]
}
