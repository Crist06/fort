type Params = {
  match_id: number
  player_out_id: number
  player_in_id: number
  minute?: number
}

export default async function (req: { params: Params; user: User }) {
  const caller = await retoolDb.query<{ role: string }>(
    `SELECT role FROM users WHERE email = $1`, [req.user.email]
  )
  const role = caller.data[0]?.role
  if (!['administrator', 'captain', 'referee'].includes(role ?? '')) throw new Error('No autorizado')

  const result = await retoolDb.query(
    `INSERT INTO match_substitutions (match_id, player_out_id, player_in_id, minute)
     VALUES ($1, $2, $3, $4) RETURNING *`,
    [req.params.match_id, req.params.player_out_id, req.params.player_in_id, req.params.minute ?? null]
  )
  return result.data[0]
}
