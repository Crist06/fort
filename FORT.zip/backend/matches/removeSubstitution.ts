type Params = { substitution_id: number }

export default async function (req: { params: Params; user: User }) {
  const caller = await retoolDb.query<{ role: string }>(
    `SELECT role FROM users WHERE email = $1`, [req.user.email]
  )
  const role = caller.data[0]?.role
  if (!['administrator', 'captain', 'referee'].includes(role ?? '')) throw new Error('No autorizado')

  await retoolDb.query(`DELETE FROM match_substitutions WHERE id = $1`, [req.params.substitution_id])
  return { ok: true }
}
