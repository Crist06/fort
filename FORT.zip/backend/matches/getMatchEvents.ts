type Params = { match_id: number }

export default async function (req: { params: Params; user: User }) {
  const result = await retoolDb.query(`
    SELECT me.*, p.name as player_name, p.nickname, p.number,
      t.name as team_name, t.primary_color as team_color
    FROM match_events me
    JOIN players p ON p.id = me.player_id
    JOIN teams t ON t.id = p.team_id
    WHERE me.match_id = $1
    ORDER BY me.minute NULLS LAST, me.created_at
  `, [req.params.match_id])
  return result.data
}
