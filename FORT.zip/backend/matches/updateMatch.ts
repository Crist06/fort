type Params = {
  match_id: number
  home_score?: number
  away_score?: number
  status?: string
  match_date?: string
  location?: string
  round?: number
  referee_id?: number
}

export default async function (req: { params: Params; user: User }) {
  const caller = await retoolDb.query<{ role: string }>(
    `SELECT role FROM users WHERE email = $1`, [req.user.email]
  )
  const role = caller.data[0]?.role
  if (!['administrator', 'captain', 'referee'].includes(role ?? '')) throw new Error('No autorizado')

  const result = await retoolDb.query(`
    UPDATE matches SET
      home_score = COALESCE($1, home_score),
      away_score = COALESCE($2, away_score),
      status = COALESCE($3, status),
      match_date = COALESCE($4::timestamp, match_date),
      location = COALESCE($5, location),
      round = COALESCE($6, round),
      referee_id = COALESCE($7, referee_id)
    WHERE id = $8
    RETURNING *
  `, [req.params.home_score ?? null, req.params.away_score ?? null,
      req.params.status ?? null, req.params.match_date ?? null,
      req.params.location ?? null, req.params.round ?? null,
      req.params.referee_id ?? null, req.params.match_id])
  return result.data[0]
}
