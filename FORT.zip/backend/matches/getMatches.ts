type Params = { season_id: number; round?: number; team_id?: number; group_id?: number }

export default async function (req: { params: Params; user: User }) {
  const { season_id, round, team_id, group_id } = req.params

  const result = await retoolDb.query(`
    WITH p AS (SELECT $1::int as sid, $2::int as rnd, $3::int as tid, $4::int as gid)
    SELECT m.*,
      ht.name as home_team_name, ht.logo_url as home_team_logo, ht.primary_color as home_color,
      at.name as away_team_name, at.logo_url as away_team_logo, at.primary_color as away_color,
      u.username as referee_name,
      g.name as group_name
    FROM matches m
    CROSS JOIN p
    JOIN teams ht ON ht.id = m.home_team_id
    JOIN teams at ON at.id = m.away_team_id
    LEFT JOIN users u ON u.id = m.referee_id
    LEFT JOIN groups g ON g.id = m.group_id
    WHERE m.season_id = p.sid
      AND (p.rnd IS NULL OR m.round = p.rnd)
      AND (p.tid IS NULL OR m.home_team_id = p.tid OR m.away_team_id = p.tid)
      AND (p.gid IS NULL OR m.group_id = p.gid)
    ORDER BY m.round, m.match_date
  `, [season_id, round ?? null, team_id ?? null, group_id ?? null])
  return result.data
}
