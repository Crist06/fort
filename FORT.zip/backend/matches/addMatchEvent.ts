type Params = {
  match_id: number
  player_id: number
  event_type: 'goal' | 'assist' | 'yellow_card' | 'red_card'
  minute?: number
}

export default async function (req: { params: Params; user: User }) {
  const caller = await retoolDb.query<{ role: string }>(
    `SELECT role FROM users WHERE email = $1`, [req.user.email]
  )
  const role = caller.data[0]?.role
  if (!['administrator', 'captain', 'referee'].includes(role ?? '')) throw new Error('No autorizado')

  const validTypes = ['goal', 'assist', 'yellow_card', 'red_card']
  if (!validTypes.includes(req.params.event_type)) throw new Error('Tipo de evento inválido')

  const result = await retoolDb.query(
    `INSERT INTO match_events (match_id, player_id, event_type, minute)
     VALUES ($1, $2, $3, $4) RETURNING *`,
    [req.params.match_id, req.params.player_id, req.params.event_type, req.params.minute ?? null]
  )
  return result.data[0]
}
