type Params = { season_id: number }

export default async function (req: { params: Params; user: User }) {
  // Find user's player record and team
  const playerRes = await retoolDb.query<{ team_id: number | null }>(
    `SELECT p.team_id FROM players p JOIN users u ON u.id = p.user_id WHERE u.email = $1 LIMIT 1`,
    [req.user.email]
  )
  const teamId = playerRes.data[0]?.team_id ?? null

  const result = await retoolDb.query(`
    WITH tid AS (SELECT $1::int as val)
    SELECT m.*,
      ht.name as home_team_name, ht.logo_url as home_team_logo, ht.primary_color as home_color,
      at.name as away_team_name, at.logo_url as away_team_logo, at.primary_color as away_color,
      u.username as referee_name,
      g.name as group_name,
      (tid.val IS NOT NULL AND (m.home_team_id = tid.val OR m.away_team_id = tid.val)) as is_my_match
    FROM matches m
    CROSS JOIN tid
    JOIN teams ht ON ht.id = m.home_team_id
    JOIN teams at ON at.id = m.away_team_id
    LEFT JOIN users u ON u.id = m.referee_id
    LEFT JOIN groups g ON g.id = m.group_id
    WHERE m.season_id = $2
    ORDER BY
      CASE WHEN (m.home_team_id = tid.val OR m.away_team_id = tid.val) THEN 0 ELSE 1 END,
      m.round,
      m.match_date
  `, [teamId, req.params.season_id])

  return { matches: result.data, my_team_id: teamId }
}
