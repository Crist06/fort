type Params = {
  match_id: number
  player_id: number
  type: 'starter' | 'substitute' | 'remove'
}

export default async function (req: { params: Params; user: User }) {
  const caller = await retoolDb.query<{ role: string }>(
    `SELECT role FROM users WHERE email = $1`, [req.user.email]
  )
  const role = caller.data[0]?.role
  if (!['administrator', 'captain', 'referee'].includes(role ?? '')) throw new Error('No autorizado')

  if (req.params.type === 'remove') {
    await retoolDb.query(
      `DELETE FROM match_lineups WHERE match_id = $1 AND player_id = $2`,
      [req.params.match_id, req.params.player_id]
    )
    return { ok: true }
  }

  const result = await retoolDb.query(
    `INSERT INTO match_lineups (match_id, player_id, type)
     VALUES ($1, $2, $3)
     ON CONFLICT (match_id, player_id) DO UPDATE SET type = $3
     RETURNING *`,
    [req.params.match_id, req.params.player_id, req.params.type]
  )
  return result.data[0]
}
