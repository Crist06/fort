type Params = { team_id: number }

export default async function (req: { params: Params; user: User }) {
  const result = await retoolDb.query(`
    SELECT p.*, u.email as user_email, u.role as user_role, u.username
    FROM players p
    LEFT JOIN users u ON u.id = p.user_id
    WHERE p.team_id = $1
    ORDER BY p.number NULLS LAST, p.name
  `, [req.params.team_id])
  return result.data
}
