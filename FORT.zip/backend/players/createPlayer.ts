type Params = {
  team_id: number
  name: string
  nickname?: string
  number?: number
  position?: string
  user_id?: number
  photo_url?: string
}

export default async function (req: { params: Params; user: User }) {
  const caller = await retoolDb.query<{ role: string }>(
    `SELECT role FROM users WHERE email = $1`, [req.user.email]
  )
  const role = caller.data[0]?.role
  if (!['administrator', 'captain'].includes(role ?? '')) throw new Error('No autorizado')

  const result = await retoolDb.query(
    `INSERT INTO players (team_id, name, nickname, number, position, user_id, photo_url)
     VALUES ($1, $2, $3, $4, $5, $6, $7) RETURNING *`,
    [req.params.team_id, req.params.name, req.params.nickname ?? null,
     req.params.number ?? null, req.params.position ?? null,
     req.params.user_id ?? null, req.params.photo_url ?? null]
  )
  return result.data[0]
}
