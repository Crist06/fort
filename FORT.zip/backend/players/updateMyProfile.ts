type Params = { nickname?: string; photo_url?: string; username?: string }

export default async function (req: { params: Params; user: User }) {
  // Update user profile
  if (req.params.username) {
    await retoolDb.query(
      `UPDATE users SET username = $1 WHERE email = $2`,
      [req.params.username, req.user.email]
    )
  }

  // Update linked player profile
  const result = await retoolDb.query(`
    UPDATE players SET
      nickname = COALESCE($1, nickname),
      photo_url = COALESCE($2, photo_url)
    WHERE user_id = (SELECT id FROM users WHERE email = $3)
    RETURNING *
  `, [req.params.nickname ?? null, req.params.photo_url ?? null, req.user.email])

  return { ok: true, player: result.data[0] ?? null }
}
