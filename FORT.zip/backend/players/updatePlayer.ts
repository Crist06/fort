type Params = {
  player_id: number
  name?: string
  nickname?: string
  number?: number
  position?: string
  user_id?: number
  photo_url?: string
  team_id?: number
  birth_date?: string
}

export default async function (req: { params: Params; user: User }) {
  const caller = await retoolDb.query<{ role: string }>(
    `SELECT role FROM users WHERE email = $1`, [req.user.email]
  )
  const role = caller.data[0]?.role
  if (!['administrator', 'captain'].includes(role ?? '')) throw new Error('No autorizado')

  const result = await retoolDb.query(`
    UPDATE players SET
      name = COALESCE($1, name),
      nickname = COALESCE($2, nickname),
      number = COALESCE($3, number),
      position = COALESCE($4, position),
      user_id = COALESCE($5, user_id),
      photo_url = COALESCE($6, photo_url),
      team_id = COALESCE($7, team_id),
      birth_date = COALESCE($8::date, birth_date)
    WHERE id = $9
    RETURNING *
  `, [req.params.name ?? null, req.params.nickname ?? null, req.params.number ?? null,
      req.params.position ?? null, req.params.user_id ?? null, req.params.photo_url ?? null,
      req.params.team_id ?? null, req.params.birth_date ?? null, req.params.player_id])
  return result.data[0]
}
