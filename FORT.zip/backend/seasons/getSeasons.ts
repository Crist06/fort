type Params = Record<string, never>

export default async function (_req: { params: Params; user: User }) {
  const result = await retoolDb.query(`
    SELECT s.*,
      COUNT(DISTINCT ts.team_id)::int as team_count,
      COUNT(DISTINCT m.id)::int as match_count
    FROM seasons s
    LEFT JOIN team_seasons ts ON ts.season_id = s.id
    LEFT JOIN matches m ON m.season_id = s.id
    GROUP BY s.id
    ORDER BY s.created_at DESC
  `)
  return result.data
}
