type Params = { season_id: number }

export default async function (req: { params: Params; user: User }) {
  const result = await retoolDb.query(
    `SELECT * FROM standing_rules WHERE season_id = $1 ORDER BY sort_order, position_from`,
    [req.params.season_id]
  )
  return result.data
}
