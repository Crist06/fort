type Params = { name: string; year: string; has_groups: boolean }

export default async function (req: { params: Params; user: User }) {
  const caller = await retoolDb.query<{ role: string }>(
    `SELECT role FROM users WHERE email = $1`, [req.user.email]
  )
  if (!caller.data[0] || caller.data[0].role !== 'administrator') {
    throw new Error('No autorizado')
  }

  const result = await retoolDb.query(
    `INSERT INTO seasons (name, year, has_groups) VALUES ($1, $2, $3) RETURNING *`,
    [req.params.name, req.params.year, req.params.has_groups]
  )
  return result.data[0]
}
