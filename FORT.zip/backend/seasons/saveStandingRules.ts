type Rule = { position_from: number; position_to: number; color: string; label: string; sort_order: number }
type Params = { season_id: number; rules: Rule[] }

export default async function (req: { params: Params; user: User }) {
  const caller = await retoolDb.query<{ role: string }>(
    `SELECT role FROM users WHERE email = $1`, [req.user.email]
  )
  if (!['administrator', 'captain'].includes(caller.data[0]?.role ?? '')) throw new Error('No autorizado')

  // Delete existing rules for this season
  await retoolDb.query(`DELETE FROM standing_rules WHERE season_id = $1`, [req.params.season_id])

  // Insert new rules
  for (const [i, rule] of req.params.rules.entries()) {
    await retoolDb.query(
      `INSERT INTO standing_rules (season_id, position_from, position_to, color, label, sort_order) VALUES ($1, $2, $3, $4, $5, $6)`,
      [req.params.season_id, rule.position_from, rule.position_to, rule.color, rule.label, i]
    )
  }

  return { ok: true, count: req.params.rules.length }
}
