type Params = { season_id: number }

export default async function (req: { params: Params; user: User }) {
  const result = await retoolDb.query(`
    SELECT g.*, COUNT(ts.team_id)::int as team_count
    FROM groups g
    LEFT JOIN team_seasons ts ON ts.group_id = g.id
    WHERE g.season_id = $1
    GROUP BY g.id
    ORDER BY g.name
  `, [req.params.season_id])
  return result.data
}
