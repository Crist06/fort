type Params = { id: number; name?: string; color?: string }

export default async function (req: { params: Params; user: User }) {
  const caller = await retoolDb.query<{ role: string }>(
    `SELECT role FROM users WHERE email = $1`, [req.user.email]
  )
  if (caller.data[0]?.role !== 'administrator') throw new Error('No autorizado')

  const result = await retoolDb.query(
    `UPDATE groups SET name = COALESCE($1, name), color = COALESCE($2, color) WHERE id = $3 RETURNING *`,
    [req.params.name ?? null, req.params.color ?? null, req.params.id]
  )
  return result.data[0]
}
