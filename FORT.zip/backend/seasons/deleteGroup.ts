type Params = { id: number }

export default async function (req: { params: Params; user: User }) {
  const caller = await retoolDb.query<{ role: string }>(
    `SELECT role FROM users WHERE email = $1`, [req.user.email]
  )
  if (caller.data[0]?.role !== 'administrator') throw new Error('No autorizado')

  await retoolDb.query(`DELETE FROM groups WHERE id = $1`, [req.params.id])
  return { ok: true }
}
