type Params = { season_id: number; name: string; color?: string }

export default async function (req: { params: Params; user: User }) {
  const caller = await retoolDb.query<{ role: string }>(
    `SELECT role FROM users WHERE email = $1`, [req.user.email]
  )
  if (!caller.data[0] || caller.data[0].role !== 'administrator') {
    throw new Error('No autorizado')
  }

  const result = await retoolDb.query(
    `INSERT INTO groups (season_id, name, color) VALUES ($1, $2, $3) RETURNING *`,
    [req.params.season_id, req.params.name, req.params.color ?? '#38bdf8']
  )
  return result.data[0]
}
