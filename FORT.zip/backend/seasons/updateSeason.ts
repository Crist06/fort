type Params = { id: number; name?: string; year?: string; status?: string; has_groups?: boolean }

export default async function (req: { params: Params; user: User }) {
  const caller = await retoolDb.query<{ role: string }>(
    `SELECT role FROM users WHERE email = $1`, [req.user.email]
  )
  if (!caller.data[0] || caller.data[0].role !== 'administrator') {
    throw new Error('No autorizado')
  }

  const result = await retoolDb.query(`
    UPDATE seasons SET
      name = COALESCE($1, name),
      year = COALESCE($2, year),
      status = COALESCE($3, status),
      has_groups = COALESCE($4, has_groups)
    WHERE id = $5
    RETURNING *
  `, [req.params.name ?? null, req.params.year ?? null, req.params.status ?? null, req.params.has_groups ?? null, req.params.id])
  return result.data[0]
}
