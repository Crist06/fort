type Params = Record<string, never>

export default async function (req: { params: Params; user: User }) {
  const result = await retoolDb.query<{ background_value: string | null }>(
    `SELECT background_value FROM users WHERE email = $1`,
    [req.user.email]
  )
  return { background_value: result.data[0]?.background_value ?? null }
}
