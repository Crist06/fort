type Params = { base64: string; filename: string; mimeType: string }

export default async function (req: { params: Params; user: User }) {
  const ext = req.params.filename.split('.').pop() ?? 'jpg'
  const safeName = `bg_${req.user.email.replace(/[^a-z0-9]/gi, '_')}_${Date.now()}.${ext}`

  const file = await retoolStorage.upload({
    fileName: safeName,
    data: req.params.base64,
    folderName: 'backgrounds',
    mimeType: req.params.mimeType,
    isPublic: true,
    shouldOverwriteOnNameCollision: false,
  })

  // Save URL to user record
  await retoolDb.query(
    `UPDATE users SET background_value = $1 WHERE email = $2`,
    [file.data.url, req.user.email]
  )

  return { url: file.data.url }
}
