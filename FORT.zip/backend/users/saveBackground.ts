type Params = { background_value: string }

export default async function (req: { params: Params; user: User }) {
  await retoolDb.query(
    `UPDATE users SET background_value = $1 WHERE email = $2`,
    [req.params.background_value, req.user.email]
  )
  return { ok: true }
}
