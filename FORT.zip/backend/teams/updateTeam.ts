type Params = {
  team_id: number
  name?: string
  logo_url?: string
  primary_color?: string
  secondary_color?: string
  coach_name?: string
  coach_photo?: string
  season_id?: number
  group_id?: number
}

export default async function (req: { params: Params; user: User }) {
  const caller = await retoolDb.query<{ role: string }>(
    `SELECT role FROM users WHERE email = $1`, [req.user.email]
  )
  const role = caller.data[0]?.role
  if (!['administrator', 'captain'].includes(role ?? '')) throw new Error('No autorizado')

  const result = await retoolDb.query(`
    UPDATE teams SET
      name = COALESCE($1, name),
      logo_url = COALESCE($2, logo_url),
      primary_color = COALESCE($3, primary_color),
      secondary_color = COALESCE($4, secondary_color),
      coach_name = COALESCE($5, coach_name),
      coach_photo = COALESCE($6, coach_photo)
    WHERE id = $7
    RETURNING *
  `, [req.params.name ?? null, req.params.logo_url ?? null,
      req.params.primary_color ?? null, req.params.secondary_color ?? null,
      req.params.coach_name ?? null, req.params.coach_photo ?? null,
      req.params.team_id])

  if (req.params.season_id !== undefined && req.params.group_id !== undefined) {
    await retoolDb.query(
      `UPDATE team_seasons SET group_id = $1 WHERE team_id = $2 AND season_id = $3`,
      [req.params.group_id, req.params.team_id, req.params.season_id]
    )
  }

  return result.data[0]
}
