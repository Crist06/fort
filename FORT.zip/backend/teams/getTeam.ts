type Params = { team_id: number; season_id?: number }

export default async function (req: { params: Params; user: User }) {
  const { team_id, season_id } = req.params

  const teamRes = await retoolDb.query(
    `SELECT * FROM teams WHERE id = $1`,
    [team_id]
  )
  if (!teamRes.data.length) throw new Error('Equipo no encontrado')

  const playersRes = await retoolDb.query(`
    WITH sid AS (SELECT $1::int as val)
    SELECT p.*,
      u.email as user_email, u.role as user_role,
      COUNT(CASE WHEN me.event_type = 'goal' THEN 1 END)::int as goals,
      COUNT(CASE WHEN me.event_type = 'assist' THEN 1 END)::int as assists,
      COUNT(CASE WHEN me.event_type = 'yellow_card' THEN 1 END)::int as yellow_cards,
      COUNT(CASE WHEN me.event_type = 'red_card' THEN 1 END)::int as red_cards
    FROM players p
    CROSS JOIN sid
    LEFT JOIN users u ON u.id = p.user_id
    LEFT JOIN match_events me ON me.player_id = p.id
    LEFT JOIN matches m ON m.id = me.match_id AND (sid.val IS NULL OR m.season_id = sid.val)
    WHERE p.team_id = $2
    GROUP BY p.id, u.email, u.role
    ORDER BY p.number NULLS LAST, p.name
  `, [season_id ?? null, team_id])

  return { ...teamRes.data[0], players: playersRes.data }
}
