type Params = { season_id?: number }

export default async function (req: { params: Params; user: User }) {
  const { season_id } = req.params

  if (season_id) {
    const result = await retoolDb.query(`
      SELECT t.*, ts.group_id, g.name as group_name,
        COUNT(p.id)::int as player_count
      FROM teams t
      JOIN team_seasons ts ON ts.team_id = t.id AND ts.season_id = $1
      LEFT JOIN groups g ON g.id = ts.group_id
      LEFT JOIN players p ON p.team_id = t.id
      GROUP BY t.id, ts.group_id, g.name
      ORDER BY t.name
    `, [season_id])
    return result.data
  }

  const result = await retoolDb.query(`
    SELECT t.*, COUNT(p.id)::int as player_count
    FROM teams t
    LEFT JOIN players p ON p.team_id = t.id
    GROUP BY t.id
    ORDER BY t.name
  `)
  return result.data
}
