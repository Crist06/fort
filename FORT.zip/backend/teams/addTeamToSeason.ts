type Params = { team_id: number; season_id: number; group_id?: number }

export default async function (req: { params: Params; user: User }) {
  const caller = await retoolDb.query<{ role: string }>(
    `SELECT role FROM users WHERE email = $1`, [req.user.email]
  )
  if (!caller.data[0] || caller.data[0].role !== 'administrator') throw new Error('No autorizado')

  const result = await retoolDb.query(
    `INSERT INTO team_seasons (team_id, season_id, group_id) VALUES ($1, $2, $3)
     ON CONFLICT (team_id, season_id) DO UPDATE SET group_id = EXCLUDED.group_id
     RETURNING *`,
    [req.params.team_id, req.params.season_id, req.params.group_id ?? null]
  )
  return result.data[0]
}
