type Params = {
  name: string
  logo_url?: string
  primary_color?: string
  secondary_color?: string
  season_id?: number
  group_id?: number
}

export default async function (req: { params: Params; user: User }) {
  const caller = await retoolDb.query<{ role: string }>(
    `SELECT role FROM users WHERE email = $1`, [req.user.email]
  )
  const role = caller.data[0]?.role
  if (!['administrator', 'captain'].includes(role ?? '')) throw new Error('No autorizado')

  const teamRes = await retoolDb.query(
    `INSERT INTO teams (name, logo_url, primary_color, secondary_color)
     VALUES ($1, $2, $3, $4) RETURNING *`,
    [req.params.name, req.params.logo_url ?? null, req.params.primary_color ?? '#3b82f6', req.params.secondary_color ?? '#ffffff']
  )
  const team = teamRes.data[0] as { id: number }

  if (req.params.season_id) {
    await retoolDb.query(
      `INSERT INTO team_seasons (team_id, season_id, group_id) VALUES ($1, $2, $3) ON CONFLICT DO NOTHING`,
      [team.id, req.params.season_id, req.params.group_id ?? null]
    )
  }

  return team
}
