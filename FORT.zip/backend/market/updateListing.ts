type Params = {
  listing_id: number
  title?: string
  description?: string
  price?: number
  image_url?: string
  category?: string
  status?: string
}

export default async function (req: { params: Params; user: User }) {
  const userRes = await retoolDb.query<{ id: number; role: string }>(
    `SELECT id, role FROM users WHERE email = $1`, [req.user.email]
  )
  if (!userRes.data[0]) throw new Error('Usuario no encontrado')

  // Check ownership (or admin)
  const listingRes = await retoolDb.query<{ user_id: number }>(
    `SELECT user_id FROM market_listings WHERE id = $1`, [req.params.listing_id]
  )
  if (!listingRes.data[0]) throw new Error('Anuncio no encontrado')
  const isOwner = listingRes.data[0].user_id === userRes.data[0].id
  const isAdmin = userRes.data[0].role === 'administrator'
  if (!isOwner && !isAdmin) throw new Error('No autorizado')

  const result = await retoolDb.query(`
    UPDATE market_listings SET
      title = COALESCE($1, title),
      description = COALESCE($2, description),
      price = COALESCE($3, price),
      image_url = COALESCE($4, image_url),
      category = COALESCE($5, category),
      status = COALESCE($6, status)
    WHERE id = $7
    RETURNING *
  `, [req.params.title ?? null, req.params.description ?? null, req.params.price ?? null,
      req.params.image_url ?? null, req.params.category ?? null, req.params.status ?? null,
      req.params.listing_id])
  return result.data[0]
}
