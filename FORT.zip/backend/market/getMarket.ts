type Params = { category?: string }

export default async function (req: { params: Params; user: User }) {
  const result = await retoolDb.query(`
    WITH cat AS (SELECT $1::text as val)
    SELECT ml.*,
      u.username as poster_name, u.avatar_url as poster_avatar,
      p.name as player_name, p.nickname as player_nickname,
      p.photo_url as player_photo, p.position as player_position,
      p.number as player_number,
      t.name as team_name, t.primary_color as team_color,
      t.logo_url as team_logo
    FROM market_listings ml
    CROSS JOIN cat
    JOIN users u ON u.id = ml.user_id
    LEFT JOIN players p ON p.id = ml.player_id
    LEFT JOIN teams t ON t.id = ml.team_id
    WHERE ml.status = 'active'
      AND (cat.val IS NULL OR ml.category = cat.val)
    ORDER BY ml.created_at DESC
  `, [req.params.category ?? null])
  return result.data
}
