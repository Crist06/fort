type Params = {
  listing_type: 'traspaso' | 'libre' | 'busca_equipo' | 'busca_jugador'
  player_id?: number
  team_id?: number
  description?: string
  price?: number
  position?: string
}

export default async function (req: { params: Params; user: User }) {
  const userRes = await retoolDb.query<{ id: number; role: string }>(
    `SELECT id, role FROM users WHERE email = $1`, [req.user.email]
  )
  if (!userRes.data[0]) throw new Error('Usuario no encontrado')

  const { role, id: userId } = userRes.data[0]

  // Traspaso and busca_jugador require captain or admin
  if (['traspaso', 'busca_jugador'].includes(req.params.listing_type)) {
    if (!['administrator', 'captain'].includes(role)) throw new Error('Solo capitanes y administradores pueden publicar traspasos')
  }

  // Get player name for title if player_id provided
  let title = req.params.position ?? 'Jugador'
  if (req.params.player_id) {
    const playerRes = await retoolDb.query<{ name: string; position: string | null }>(
      `SELECT name, position FROM players WHERE id = $1`, [req.params.player_id]
    )
    if (playerRes.data[0]) {
      title = playerRes.data[0].name
    }
  }

  const result = await retoolDb.query(
    `INSERT INTO market_listings (user_id, player_id, team_id, title, description, price, category, status)
     VALUES ($1, $2, $3, $4, $5, $6, $7, 'active') RETURNING *`,
    [userId, req.params.player_id ?? null, req.params.team_id ?? null,
     title, req.params.description ?? null, req.params.price ?? null,
     req.params.listing_type]
  )
  return result.data[0]
}
