type Params = Record<string, never>

export default async function (req: { params: Params; user: User }) {
  const caller = await retoolDb.query<{ role: string }>(
    `SELECT role FROM users WHERE email = $1`, [req.user.email]
  )
  if (!caller.data[0] || caller.data[0].role !== 'administrator') {
    throw new Error('No autorizado')
  }

  const result = await retoolDb.query(`
    SELECT u.id, u.email, u.username, u.role, u.avatar_url, u.created_at,
      p.id as player_id, p.name as player_name, p.team_id,
      t.name as team_name
    FROM users u
    LEFT JOIN players p ON p.user_id = u.id
    LEFT JOIN teams t ON t.id = p.team_id
    ORDER BY u.created_at DESC
  `)
  return result.data
}
