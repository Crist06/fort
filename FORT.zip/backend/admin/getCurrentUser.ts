type Params = Record<string, never>

export default async function (req: { params: Params; user: User }) {
  // Try to find existing user
  const existing = await retoolDb.query<{
    id: number; email: string; username: string; role: string;
    avatar_url: string | null; player_id: number | null; player_name: string | null;
    nickname: string | null; photo_url: string | null; team_id: number | null;
    number: number | null; position: string | null
  }>(
    `SELECT u.id, u.email, u.username, u.role, u.avatar_url,
      p.id as player_id, p.name as player_name, p.nickname, p.photo_url, p.team_id, p.number, p.position
     FROM users u
     LEFT JOIN players p ON p.user_id = u.id
     WHERE u.email = $1`,
    [req.user.email]
  )

  if (existing.data.length > 0) return existing.data[0]

  // Auto-create if first login
  const fullName = `${req.user.firstName ?? ''} ${req.user.lastName ?? ''}`.trim() || req.user.email
  const created = await retoolDb.query<{ id: number; email: string; username: string; role: string; avatar_url: string | null }>(
    `INSERT INTO users (email, username, role) VALUES ($1, $2, 'player') RETURNING *`,
    [req.user.email, fullName]
  )
  return { ...created.data[0], player_id: null, player_name: null, nickname: null, photo_url: null, team_id: null, number: null, position: null }
}
