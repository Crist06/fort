type Params = { user_id: number; role: string }

export default async function (req: { params: Params; user: User }) {
  const caller = await retoolDb.query<{ role: string }>(
    `SELECT role FROM users WHERE email = $1`, [req.user.email]
  )
  if (!caller.data[0] || caller.data[0].role !== 'administrator') {
    throw new Error('No autorizado')
  }

  const validRoles = ['player', 'captain', 'referee', 'administrator']
  if (!validRoles.includes(req.params.role)) throw new Error('Rol inválido')

  const result = await retoolDb.query(
    `UPDATE users SET role = $1 WHERE id = $2 RETURNING *`,
    [req.params.role, req.params.user_id]
  )
  return result.data[0]
}
