export interface AppUser {
  id: number
  email: string
  username: string
  role: 'player' | 'captain' | 'referee' | 'administrator'
  avatar_url: string | null
  player_id: number | null
  player_name: string | null
  nickname: string | null
  photo_url: string | null
  team_id: number | null
  number: number | null
  position: string | null
}

export interface Season {
  id: number
  name: string
  year: string
  has_groups: boolean
  status: 'active' | 'finished'
  team_count: number
  match_count: number
  created_at: string
}

export interface Group {
  id: number
  season_id: number
  name: string
  team_count: number
}

export interface Team {
  id: number
  name: string
  logo_url: string | null
  primary_color: string
  secondary_color: string
  player_count?: number
  group_id?: number | null
  group_name?: string | null
}

export interface Player {
  id: number
  user_id: number | null
  team_id: number
  name: string
  nickname: string | null
  photo_url: string | null
  number: number | null
  position: string | null
  user_email?: string | null
  user_role?: string | null
  username?: string | null
}

export interface Match {
  id: number
  season_id: number
  group_id: number | null
  home_team_id: number
  away_team_id: number
  home_score: number
  away_score: number
  match_date: string | null
  round: number | null
  status: string
  referee_id: number | null
  location: string | null
  created_at: string
  home_team_name: string
  home_team_logo: string | null
  home_color: string
  away_team_name: string
  away_team_logo: string | null
  away_color: string
  referee_name: string | null
  group_name: string | null
  is_my_match?: boolean
}

export interface Standing {
  id: number
  name: string
  logo_url: string | null
  primary_color: string
  secondary_color: string
  played: number
  won: number
  drawn: number
  lost: number
  goals_for: number
  goals_against: number
  goal_diff: number
  points: number
}

export interface PlayerStat {
  id: number
  name: string
  nickname: string | null
  photo_url: string | null
  position: string | null
  number: number | null
  team_name: string
  team_color: string
  team_logo: string | null
  goals: number
  assists: number
  yellow_cards: number
  red_cards: number
}

export interface MarketListing {
  id: number
  user_id: number
  title: string
  description: string | null
  price: number | null
  image_url: string | null
  category: string
  status: string
  created_at: string
  seller_name: string
  seller_avatar: string | null
  seller_nickname: string | null
}
