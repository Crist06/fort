import { Routes, Route } from 'react-router-dom'
import { AppProvider } from './context/AppContext'
import Layout from './components/Layout'
import Home from './pages/Home'
import Clasificacion from './pages/Clasificacion'
import Estadisticas from './pages/Estadisticas'
import Equipos from './pages/Equipos'
import Partidos from './pages/Partidos'
import MisPartidos from './pages/MisPartidos'
import Temporadas from './pages/Temporadas'
import Mercado from './pages/Mercado'
import Perfil from './pages/Perfil'
import Admin from './pages/Admin'

export default function App() {
  return (
    <AppProvider>
      <Layout>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/clasificacion" element={<Clasificacion />} />
          <Route path="/estadisticas" element={<Estadisticas />} />
          <Route path="/equipos" element={<Equipos />} />
          <Route path="/partidos" element={<Partidos />} />
          <Route path="/mis-partidos" element={<MisPartidos />} />
          <Route path="/temporadas" element={<Temporadas />} />
          <Route path="/mercado" element={<Mercado />} />
          <Route path="/perfil" element={<Perfil />} />
          <Route path="/admin" element={<Admin />} />
        </Routes>
      </Layout>
    </AppProvider>
  )
}
