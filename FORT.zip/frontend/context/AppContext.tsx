import { createContext, useContext, useState, useEffect, useCallback } from 'react'
import { useGetCurrentUser } from '../hooks/backend/admin'
import { useGetSeasons } from '../hooks/backend/seasons'
import { useGetBackground } from '../hooks/backend/users'
import type { AppUser, Season } from '../types'

const BG_KEY = 'app_background'

interface AppContextValue {
  appUser: AppUser | null
  userLoading: boolean
  activeSeason: Season | null
  seasons: Season[]
  setActiveSeason: (season: Season) => void
  refreshUser: () => void
  refreshSeasons: () => void
  background: string
  setBackground: (bg: string) => void
}

const AppContext = createContext<AppContextValue>({
  appUser: null,
  userLoading: true,
  activeSeason: null,
  seasons: [],
  setActiveSeason: () => {},
  refreshUser: () => {},
  refreshSeasons: () => {},
  background: '',
  setBackground: () => {},
})

export function AppProvider({ children }: { children: React.ReactNode }) {
  const { data: userData, loading: userLoading, trigger: triggerUser } = useGetCurrentUser()
  const { data: seasonsData, trigger: triggerSeasons } = useGetSeasons()
  const { data: bgData, trigger: triggerBg } = useGetBackground()
  const [activeSeason, setActiveSeason] = useState<Season | null>(null)
  const [background, _setBackground] = useState<string>(() => localStorage.getItem(BG_KEY) ?? '')

  const setBackground = useCallback((bg: string) => {
    _setBackground(bg)
    localStorage.setItem(BG_KEY, bg)
  }, [])

  const refreshUser = useCallback(() => { triggerUser() }, [triggerUser])
  const refreshSeasons = useCallback(() => { triggerSeasons() }, [triggerSeasons])

  useEffect(() => {
    triggerUser()
    triggerSeasons()
    triggerBg()
  }, [])

  // Sync background from DB once loaded
  useEffect(() => {
    const serverBg = (bgData as { background_value: string | null } | undefined)?.background_value
    if (serverBg) setBackground(serverBg)
  }, [bgData])

  const seasons = (seasonsData as Season[] | undefined) ?? []

  useEffect(() => {
    if (seasons.length > 0 && !activeSeason) {
      const active = seasons.find(s => s.status === 'active') ?? seasons[0]
      if (active) setActiveSeason(active)
    }
  }, [seasons, activeSeason])

  return (
    <AppContext.Provider value={{
      appUser: userData as AppUser | null,
      userLoading,
      activeSeason,
      seasons,
      setActiveSeason,
      refreshUser,
      refreshSeasons,
      background,
      setBackground,
    }}>
      {children}
    </AppContext.Provider>
  )
}

export const useAppContext = () => useContext(AppContext)
