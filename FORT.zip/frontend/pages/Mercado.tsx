import { useEffect, useState } from 'react'
import { RefreshCw, UserPlus, UserSearch, Users, Plus, Check, Euro } from 'lucide-react'
import { useGetMarket, useCreateListing, useUpdateListing } from '../hooks/backend/market'
import { useGetTeams } from '../hooks/backend/teams'
import { useGetPlayers } from '../hooks/backend/players'
import { useAppContext } from '../context/AppContext'
import type { Team } from '../types'
import { cn } from '../lib/shadcn/utils'
import { Button } from '../lib/shadcn/button'
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '../lib/shadcn/dialog'
import { Input } from '../lib/shadcn/input'
import { Textarea } from '../lib/shadcn/textarea'

type ListingType = 'traspaso' | 'libre' | 'busca_equipo' | 'busca_jugador'

interface MarketItem {
  id: number
  user_id: number
  title: string
  description: string | null
  price: string | null
  category: string
  status: string
  created_at: string
  player_id: number | null
  team_id: number | null
  poster_name: string
  player_name: string | null
  player_nickname: string | null
  player_photo: string | null
  player_position: string | null
  player_number: number | null
  team_name: string | null
  team_color: string | null
  team_logo: string | null
}

interface PlayerRecord {
  id: number
  name: string
  nickname: string | null
  position: string | null
  number: number | null
}

const TABS: { key: string; label: string; icon: React.ReactNode; desc: string }[] = [
  {
    key: 'todos',
    label: 'Todos',
    icon: <Users className="w-4 h-4" />,
    desc: 'Todo el mercado',
  },
  {
    key: 'traspaso',
    label: 'Traspasos',
    icon: <RefreshCw className="w-4 h-4" />,
    desc: 'Jugadores disponibles para traspaso',
  },
  {
    key: 'libre',
    label: 'Agentes Libres',
    icon: <UserPlus className="w-4 h-4" />,
    desc: 'Jugadores sin equipo disponibles',
  },
  {
    key: 'busca_equipo',
    label: 'Buscan Equipo',
    icon: <UserSearch className="w-4 h-4" />,
    desc: 'Jugadores buscando equipo',
  },
  {
    key: 'busca_jugador',
    label: 'Buscan Jugador',
    icon: <Users className="w-4 h-4" />,
    desc: 'Equipos buscando fichajes',
  },
]

const TYPE_STYLES: Record<string, { label: string; color: string; bg: string }> = {
  traspaso: {
    label: '🔄 Traspaso',
    color: 'text-blue-700 dark:text-blue-300',
    bg: 'bg-blue-100 dark:bg-blue-900',
  },
  libre: {
    label: '🆓 Agente Libre',
    color: 'text-green-700 dark:text-green-300',
    bg: 'bg-green-100 dark:bg-green-900',
  },
  busca_equipo: {
    label: '🔍 Busca Equipo',
    color: 'text-yellow-700 dark:text-yellow-300',
    bg: 'bg-yellow-100 dark:bg-yellow-900',
  },
  busca_jugador: {
    label: '📢 Busca Jugador',
    color: 'text-purple-700 dark:text-purple-300',
    bg: 'bg-purple-100 dark:bg-purple-900',
  },
}

const POSITIONS = ['Portero', 'Defensa', 'Mediocampista', 'Delantero']

function PlayerAvatar({ photo, name, color, size = 'md' }: {
  photo: string | null; name: string; color: string | null; size?: 'sm' | 'md' | 'lg'
}) {
  const sizeClass = size === 'lg' ? 'w-16 h-16 text-xl' : size === 'sm' ? 'w-8 h-8 text-xs' : 'w-12 h-12 text-sm'
  return photo ? (
    <img src={photo} className={cn(sizeClass, 'rounded-full object-cover flex-shrink-0')} alt={name} />
  ) : (
    <div
      className={cn(sizeClass, 'rounded-full flex items-center justify-center font-bold text-white flex-shrink-0')}
      style={{ backgroundColor: color ?? '#6b7280' }}
    >
      {name.slice(0, 2).toUpperCase()}
    </div>
  )
}

function ListingCard({ item, canManage, onClose }: {
  item: MarketItem; canManage: boolean; onClose: () => void
}) {
  const style = (TYPE_STYLES[item.category] ?? TYPE_STYLES['libre'])!
  const isBuscaJugador = item.category === 'busca_jugador'
  const displayName = isBuscaJugador
    ? (item.team_name ?? 'Equipo')
    : (item.player_nickname ? `"${item.player_nickname}"` : item.player_name ?? item.title)

  return (
    <div className="bg-card border border-border rounded-xl overflow-hidden hover:shadow-md hover:border-primary/30 transition-all">
      {/* Top color bar from team */}
      <div
        className="h-1.5"
        style={{ backgroundColor: item.team_color ?? '#6b7280' }}
      />
      <div className="p-4">
        {/* Badge */}
        <div className="flex items-center justify-between mb-3">
          <span className={cn('text-xs px-2 py-0.5 rounded-full font-semibold', style.bg, style.color)}>
            {style.label}
          </span>
          {item.price && (
            <span className="flex items-center gap-0.5 text-sm font-bold text-foreground">
              <Euro className="w-3.5 h-3.5" />
              {parseFloat(item.price).toLocaleString('es-ES')}
            </span>
          )}
        </div>

        {/* Player / Team info */}
        <div className="flex items-center gap-3 mb-3">
          <PlayerAvatar
            photo={item.player_photo}
            name={isBuscaJugador ? (item.team_name ?? 'E') : (item.player_name ?? item.title)}
            color={item.team_color}
            size="md"
          />
          <div className="flex-1 min-w-0">
            <p className="font-bold text-foreground truncate">{displayName}</p>
            {!isBuscaJugador && item.player_name && item.player_nickname && (
              <p className="text-xs text-muted-foreground truncate">{item.player_name}</p>
            )}
            <div className="flex items-center gap-1.5 mt-0.5 flex-wrap">
              {item.player_position && (
                <span className="text-xs bg-muted text-muted-foreground px-1.5 py-0.5 rounded">
                  {item.player_position}
                </span>
              )}
              {item.player_number && (
                <span className="text-xs bg-muted text-muted-foreground px-1.5 py-0.5 rounded">
                  #{item.player_number}
                </span>
              )}
              {item.team_name && (
                <span className="flex items-center gap-1 text-xs text-muted-foreground">
                  <span
                    className="inline-block w-2 h-2 rounded-full"
                    style={{ backgroundColor: item.team_color ?? '#6b7280' }}
                  />
                  {item.team_name}
                </span>
              )}
            </div>
          </div>
        </div>

        {/* Description */}
        {item.description && (
          <p className="text-sm text-muted-foreground leading-relaxed line-clamp-2 mb-3">
            {item.description}
          </p>
        )}

        {/* Footer */}
        <div className="flex items-center justify-between pt-2 border-t border-border/50">
          <span className="text-xs text-muted-foreground">
            {new Date(item.created_at).toLocaleDateString('es-ES', { day: 'numeric', month: 'short' })}
          </span>
          {canManage && (
            <button
              onClick={onClose}
              className="text-xs text-red-500 hover:underline font-medium"
            >
              Cerrar oferta
            </button>
          )}
        </div>
      </div>
    </div>
  )
}

const FORM_TYPES: { value: ListingType; label: string; requiresPlayer: boolean; requiresTeam: boolean }[] = [
  { value: 'traspaso', label: '🔄 Traspaso — Poner jugador en el mercado', requiresPlayer: true, requiresTeam: true },
  { value: 'libre', label: '🆓 Agente Libre — Jugador disponible sin equipo', requiresPlayer: true, requiresTeam: false },
  { value: 'busca_equipo', label: '🔍 Busca Equipo — Jugador buscando club', requiresPlayer: true, requiresTeam: false },
  { value: 'busca_jugador', label: '📢 Busca Jugador — Equipo buscando fichaje', requiresPlayer: false, requiresTeam: true },
]

export default function Mercado() {
  const { appUser } = useAppContext()
  const { data: listingsData, loading, trigger: triggerMarket } = useGetMarket()
  const { trigger: createListing } = useCreateListing()
  const { trigger: updateListing } = useUpdateListing()
  const { data: teamsData, trigger: triggerTeams } = useGetTeams()
  const { data: playersData, trigger: triggerPlayers } = useGetPlayers()

  const [activeTab, setActiveTab] = useState('todos')
  const [showForm, setShowForm] = useState(false)

  // Form state
  const [listingType, setListingType] = useState<ListingType>('traspaso')
  const [selectedTeamId, setSelectedTeamId] = useState('')
  const [selectedPlayerId, setSelectedPlayerId] = useState('')
  const [description, setDescription] = useState('')
  const [price, setPrice] = useState('')
  const [position, setPosition] = useState('')

  const isAdmin = appUser?.role === 'administrator'
  const isCaptain = appUser?.role === 'captain'
  const canPublish = isAdmin || isCaptain || appUser?.role === 'player'

  useEffect(() => {
    triggerMarket(activeTab !== 'todos' ? { category: activeTab } : {})
  }, [activeTab])

  useEffect(() => {
    if (showForm) {
      triggerTeams({})
    }
  }, [showForm])

  useEffect(() => {
    if (selectedTeamId) {
      triggerPlayers({ team_id: parseInt(selectedTeamId) })
      setSelectedPlayerId('')
    }
  }, [selectedTeamId])

  const listings = (listingsData as MarketItem[] | undefined) ?? []
  const teams = (teamsData as Team[] | undefined) ?? []
  const players = (playersData as PlayerRecord[] | undefined) ?? []

  const currentType = FORM_TYPES.find(t => t.value === listingType)

  async function handleCreate() {
    if (!listingType) return
    if (currentType?.requiresPlayer && !selectedPlayerId) return
    if (currentType?.requiresTeam && !selectedTeamId) return

    await createListing({
      listing_type: listingType,
      player_id: selectedPlayerId ? parseInt(selectedPlayerId) : undefined,
      team_id: selectedTeamId ? parseInt(selectedTeamId) : undefined,
      description: description || undefined,
      price: price ? parseFloat(price) : undefined,
      position: position || undefined,
    })
    setShowForm(false)
    resetForm()
    triggerMarket(activeTab !== 'todos' ? { category: activeTab } : {})
  }

  function resetForm() {
    setListingType('traspaso')
    setSelectedTeamId('')
    setSelectedPlayerId('')
    setDescription('')
    setPrice('')
    setPosition('')
  }

  async function handleClose(id: number) {
    await updateListing({ listing_id: id, status: 'completed' })
    triggerMarket(activeTab !== 'todos' ? { category: activeTab } : {})
  }

  return (
    <div className="p-6 max-w-5xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-primary flex items-center justify-center">
            <RefreshCw className="w-5 h-5 text-primary-foreground" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-foreground">Mercado de Fichajes</h1>
            <p className="text-sm text-muted-foreground">Traspasos, agentes libres y búsqueda de jugadores</p>
          </div>
        </div>
        {canPublish && (
          <Button size="sm" onClick={() => setShowForm(true)}>
            <Plus className="w-4 h-4 mr-1" /> Publicar oferta
          </Button>
        )}
      </div>

      {/* Tabs */}
      <div className="flex gap-1 mb-6 bg-muted rounded-xl p-1 overflow-x-auto">
        {TABS.map(tab => (
          <button
            key={tab.key}
            onClick={() => setActiveTab(tab.key)}
            className={cn(
              'flex-shrink-0 flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-medium transition-colors',
              activeTab === tab.key
                ? 'bg-background text-foreground shadow-sm'
                : 'text-muted-foreground hover:text-foreground'
            )}
          >
            {tab.icon}
            <span className="hidden sm:block">{tab.label}</span>
          </button>
        ))}
      </div>

      {/* Active tab description */}
      <p className="text-sm text-muted-foreground mb-4">
        {TABS.find(t => t.key === activeTab)?.desc}
        {listings.length > 0 && <span className="ml-2 font-medium text-foreground">· {listings.length} ofertas activas</span>}
      </p>

      {/* Listings grid */}
      {loading ? (
        <div className="text-center py-16 text-muted-foreground">Cargando mercado...</div>
      ) : listings.length === 0 ? (
        <div className="text-center py-16 text-muted-foreground">
          <RefreshCw className="w-12 h-12 mx-auto mb-3 opacity-20" />
          <p className="font-medium">No hay ofertas activas en esta categoría</p>
          {canPublish && (
            <button onClick={() => setShowForm(true)} className="mt-2 text-sm text-primary hover:underline">
              Publicar la primera oferta
            </button>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {listings.map(item => (
            <ListingCard
              key={item.id}
              item={item}
              canManage={isAdmin || item.user_id === appUser?.id}
              onClose={() => handleClose(item.id)}
            />
          ))}
        </div>
      )}

      {/* Create listing dialog */}
      <Dialog open={showForm} onOpenChange={(open) => { if (!open) { setShowForm(false); resetForm() } }}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Nueva Oferta de Mercado</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 mt-2">
            {/* Type selector */}
            <div>
              <label className="text-xs font-medium text-muted-foreground mb-1.5 block">Tipo de oferta</label>
              <div className="space-y-2">
                {FORM_TYPES.filter(t =>
                  // Players can only post busca_equipo
                  // Captains/admins can post everything
                  (!isAdmin && !isCaptain) ? t.value === 'busca_equipo' : true
                ).map(t => (
                  <label
                    key={t.value}
                    className={cn(
                      'flex items-center gap-3 p-3 rounded-lg border cursor-pointer transition-colors',
                      listingType === t.value
                        ? 'border-primary bg-primary/5'
                        : 'border-border hover:border-primary/40'
                    )}
                  >
                    <input
                      type="radio"
                      name="listing_type"
                      value={t.value}
                      checked={listingType === t.value}
                      onChange={() => setListingType(t.value)}
                      className="accent-primary"
                    />
                    <span className="text-sm text-foreground">{t.label}</span>
                  </label>
                ))}
              </div>
            </div>

            {/* Team selector (if needed) */}
            {currentType?.requiresTeam && (
              <div>
                <label className="text-xs font-medium text-muted-foreground mb-1.5 block">Equipo</label>
                <select
                  value={selectedTeamId}
                  onChange={e => setSelectedTeamId(e.target.value)}
                  className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm text-foreground"
                >
                  <option value="">Seleccionar equipo...</option>
                  {teams.map(t => <option key={t.id} value={t.id}>{t.name}</option>)}
                </select>
              </div>
            )}

            {/* Player selector (if needed) */}
            {currentType?.requiresPlayer && (
              <div>
                <label className="text-xs font-medium text-muted-foreground mb-1.5 block">Jugador</label>
                {currentType.requiresTeam && !selectedTeamId ? (
                  <p className="text-xs text-muted-foreground italic">Selecciona un equipo primero</p>
                ) : (
                  <select
                    value={selectedPlayerId}
                    onChange={e => setSelectedPlayerId(e.target.value)}
                    className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm text-foreground"
                  >
                    <option value="">Seleccionar jugador...</option>
                    {players.map(p => (
                      <option key={p.id} value={p.id}>
                        {p.number ? `#${p.number} ` : ''}{p.name}{p.position ? ` · ${p.position}` : ''}
                      </option>
                    ))}
                  </select>
                )}
              </div>
            )}

            {/* Position (for busca_jugador) */}
            {listingType === 'busca_jugador' && (
              <div>
                <label className="text-xs font-medium text-muted-foreground mb-1.5 block">Posición buscada</label>
                <select
                  value={position}
                  onChange={e => setPosition(e.target.value)}
                  className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm text-foreground"
                >
                  <option value="">Cualquier posición</option>
                  {POSITIONS.map(p => <option key={p} value={p}>{p}</option>)}
                </select>
              </div>
            )}

            {/* Transfer fee */}
            {listingType === 'traspaso' && (
              <div>
                <label className="text-xs font-medium text-muted-foreground mb-1.5 block">Precio de traspaso (€, opcional)</label>
                <Input
                  type="number"
                  min="0"
                  step="50"
                  placeholder="Ej: 500"
                  value={price}
                  onChange={e => setPrice(e.target.value)}
                />
              </div>
            )}

            {/* Description */}
            <div>
              <label className="text-xs font-medium text-muted-foreground mb-1.5 block">Descripción</label>
              <Textarea
                placeholder="Describe las características del jugador, condiciones del traspaso..."
                value={description}
                onChange={e => setDescription(e.target.value)}
                rows={3}
              />
            </div>

            <div className="flex gap-2 justify-end pt-2">
              <Button variant="outline" size="sm" onClick={() => { setShowForm(false); resetForm() }}>Cancelar</Button>
              <Button
                size="sm"
                disabled={
                  (currentType?.requiresPlayer && !selectedPlayerId) ||
                  (currentType?.requiresTeam && !selectedTeamId)
                }
                onClick={handleCreate}
              >
                <Check className="w-4 h-4 mr-1" /> Publicar
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
