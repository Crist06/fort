import { useEffect } from 'react'
import { Star, MapPin, Clock } from 'lucide-react'
import { useGetMyMatches } from '../hooks/backend/matches'
import { useAppContext } from '../context/AppContext'
import type { Match } from '../types'
import { cn } from '../lib/shadcn/utils'

const STATUS_COLORS: Record<string, string> = {
  scheduled: 'bg-blue-100 text-blue-700 dark:bg-blue-900 dark:text-blue-300',
  live: 'bg-green-100 text-green-700 dark:bg-green-900 dark:text-green-300',
  finished: 'bg-muted text-muted-foreground',
  cancelled: 'bg-red-100 text-red-700 dark:bg-red-900 dark:text-red-300',
}
const STATUS_LABELS: Record<string, string> = {
  scheduled: 'Programado', live: 'En vivo', finished: 'Finalizado', cancelled: 'Cancelado',
}

function formatDate(dateStr: string | null) {
  if (!dateStr) return 'Por confirmar'
  const d = new Date(dateStr)
  return d.toLocaleDateString('es-ES', { weekday: 'short', day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })
}

function MatchItem({ match, isMine }: { match: Match; isMine: boolean }) {
  const isFinished = match.status === 'finished'
  return (
    <div className={cn(
      'bg-card border rounded-xl overflow-hidden transition-all',
      isMine ? 'border-primary/50 shadow-sm' : 'border-border'
    )}>
      {isMine && (
        <div className="px-4 py-1.5 bg-primary/10 border-b border-primary/20 flex items-center gap-1.5">
          <Star className="w-3.5 h-3.5 text-primary fill-primary" />
          <span className="text-xs font-semibold text-primary">Mi partido</span>
        </div>
      )}
      <div className="px-4 py-1.5 flex items-center justify-between border-b border-border/50">
        <span className={cn('text-xs px-2 py-0.5 rounded-full font-medium', STATUS_COLORS[match.status] ?? STATUS_COLORS['scheduled'])}>
          {STATUS_LABELS[match.status] ?? match.status}
        </span>
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <span>Jornada {match.round}</span>
          {match.group_name && <span className="bg-muted px-1.5 py-0.5 rounded">Grupo {match.group_name}</span>}
        </div>
      </div>
      <div className="px-4 py-4">
        <div className="flex items-center gap-3">
          <div className="flex-1 flex items-center gap-2 justify-end min-w-0">
            <span className={cn('font-semibold text-sm truncate text-right',
              isFinished && match.home_score > match.away_score ? 'text-foreground' : isFinished ? 'text-muted-foreground' : 'text-foreground'
            )}>
              {match.home_team_name}
            </span>
            <div className="w-8 h-8 rounded-full flex-shrink-0 flex items-center justify-center text-white text-xs font-bold"
              style={{ backgroundColor: match.home_color }}>
              {match.home_team_name.slice(0, 1)}
            </div>
          </div>

          <div className="flex-shrink-0 min-w-[70px] text-center">
            {isFinished ? (
              <div className="bg-muted rounded-lg px-3 py-2">
                <span className="font-bold text-xl text-foreground">{match.home_score} - {match.away_score}</span>
              </div>
            ) : (
              <div className="border-2 border-dashed border-border rounded-lg px-3 py-2">
                <span className="text-muted-foreground font-bold text-sm">VS</span>
              </div>
            )}
          </div>

          <div className="flex-1 flex items-center gap-2 min-w-0">
            <div className="w-8 h-8 rounded-full flex-shrink-0 flex items-center justify-center text-white text-xs font-bold"
              style={{ backgroundColor: match.away_color }}>
              {match.away_team_name.slice(0, 1)}
            </div>
            <span className={cn('font-semibold text-sm truncate',
              isFinished && match.away_score > match.home_score ? 'text-foreground' : isFinished ? 'text-muted-foreground' : 'text-foreground'
            )}>
              {match.away_team_name}
            </span>
          </div>
        </div>

        <div className="flex items-center justify-center gap-4 mt-3 text-xs text-muted-foreground">
          <div className="flex items-center gap-1">
            <Clock className="w-3.5 h-3.5" />
            <span>{formatDate(match.match_date)}</span>
          </div>
          {match.location && (
            <div className="flex items-center gap-1">
              <MapPin className="w-3.5 h-3.5" />
              <span>{match.location}</span>
            </div>
          )}
        </div>
        {match.referee_name && (
          <p className="text-center text-xs text-muted-foreground mt-1">
            Árbitro: {match.referee_name}
          </p>
        )}
      </div>
    </div>
  )
}

export default function MisPartidos() {
  const { activeSeason, appUser } = useAppContext()
  const { data, loading, trigger } = useGetMyMatches()

  useEffect(() => {
    if (activeSeason) {
      trigger({ season_id: activeSeason.id })
    }
  }, [activeSeason?.id])

  const result = data as { matches: Match[]; my_team_id: number | null } | undefined
  const matches = result?.matches ?? []
  const myTeamId = result?.my_team_id ?? null

  const myMatches = matches.filter(m => m.is_my_match)
  const otherMatches = matches.filter(m => !m.is_my_match)

  if (!appUser?.player_id) {
    return (
      <div className="p-6 max-w-2xl mx-auto">
        <div className="flex items-center gap-3 mb-6">
          <Star className="w-6 h-6 text-primary" />
          <h1 className="text-2xl font-bold text-foreground">Mis Partidos</h1>
        </div>
        <div className="bg-card border border-border rounded-xl p-8 text-center">
          <Star className="w-12 h-12 text-muted-foreground mx-auto mb-3" />
          <h2 className="text-lg font-semibold text-foreground mb-2">Sin jugador vinculado</h2>
          <p className="text-muted-foreground text-sm">
            Tu cuenta no está vinculada a ningún jugador. Pide al administrador o capitán que te asigne un jugador.
          </p>
        </div>
      </div>
    )
  }

  return (
    <div className="p-6 max-w-2xl mx-auto">
      <div className="flex items-center gap-3 mb-6">
        <Star className="w-6 h-6 text-primary fill-primary" />
        <div>
          <h1 className="text-2xl font-bold text-foreground">Mis Partidos</h1>
          {appUser.player_name && (
            <p className="text-sm text-muted-foreground">{appUser.nickname ?? appUser.player_name}</p>
          )}
        </div>
      </div>

      {loading ? (
        <div className="text-center py-12 text-muted-foreground">Cargando partidos...</div>
      ) : (
        <>
          {myMatches.length > 0 && (
            <div className="mb-6">
              <h2 className="text-sm font-semibold text-foreground mb-3 flex items-center gap-2">
                <Star className="w-4 h-4 text-primary fill-primary" /> Mis partidos
              </h2>
              <div className="space-y-3">
                {myMatches.map(m => <MatchItem key={m.id} match={m} isMine={true} />)}
              </div>
            </div>
          )}

          {myTeamId === null && matches.length === 0 && (
            <div className="text-center py-8 text-muted-foreground">No hay partidos en esta temporada</div>
          )}

          {otherMatches.length > 0 && (
            <div>
              <h2 className="text-sm font-semibold text-muted-foreground mb-3 uppercase tracking-wide">
                Otros partidos de la jornada
              </h2>
              <div className="space-y-3">
                {otherMatches.map(m => <MatchItem key={m.id} match={m} isMine={false} />)}
              </div>
            </div>
          )}
        </>
      )}
    </div>
  )
}
