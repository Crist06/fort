import { useEffect, useState } from 'react'
import { Calendar, Plus, Check, Layers, Users, Trash2, Edit2 } from 'lucide-react'
import {
  useGetSeasons, useCreateSeason, useUpdateSeason, useDeleteSeason,
  useGetGroups, useCreateGroup, useUpdateGroup, useDeleteGroup
} from '../hooks/backend/seasons'
import { useGetTeams, useAddTeamToSeason } from '../hooks/backend/teams'
import { useAppContext } from '../context/AppContext'
import type { Season, Group, Team } from '../types'
import { cn } from '../lib/shadcn/utils'
import { Button } from '../lib/shadcn/button'
import { Input } from '../lib/shadcn/input'
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '../lib/shadcn/dialog'

const STATUS_COLORS = {
  active: 'bg-green-100 text-green-700 dark:bg-green-900 dark:text-green-300',
  finished: 'bg-muted text-muted-foreground',
}

const PRESET_COLORS = ['#38bdf8','#f59e0b','#22c55e','#a855f7','#f97316','#ec4899','#ef4444','#6366f1']

function GroupRow({ group, canEdit, onEdit, onDelete }: {
  group: Group & { color?: string }; canEdit: boolean
  onEdit: (g: Group & { color?: string }) => void
  onDelete: (id: number) => void
}) {
  return (
    <div className="flex items-center gap-3 px-4 py-3 border-b border-border/50">
      <div className="w-3 h-3 rounded-full flex-shrink-0" style={{ backgroundColor: group.color ?? '#38bdf8' }} />
      <div className="flex-1">
        <span className="font-medium text-foreground text-sm">Grupo {group.name}</span>
        <span className="text-xs text-muted-foreground ml-2">{group.team_count} equipos</span>
      </div>
      {canEdit && (
        <div className="flex gap-1">
          <button onClick={() => onEdit(group)} className="p-1.5 rounded hover:bg-muted text-muted-foreground hover:text-foreground transition-colors">
            <Edit2 className="w-3.5 h-3.5" />
          </button>
          <button onClick={() => onDelete(group.id)} className="p-1.5 rounded hover:bg-muted text-muted-foreground hover:text-red-500 transition-colors">
            <Trash2 className="w-3.5 h-3.5" />
          </button>
        </div>
      )}
    </div>
  )
}

export default function Temporadas() {
  const { appUser, refreshSeasons } = useAppContext()
  const { data: seasonsData, loading, trigger: triggerSeasons } = useGetSeasons()
  const { trigger: createSeason } = useCreateSeason()
  const { trigger: updateSeason } = useUpdateSeason()
  const { trigger: deleteSeason } = useDeleteSeason()
  const { data: groupsData, trigger: triggerGroups } = useGetGroups()
  const { trigger: createGroup } = useCreateGroup()
  const { trigger: updateGroup } = useUpdateGroup()
  const { trigger: deleteGroup } = useDeleteGroup()
  const { data: allTeamsData, trigger: triggerAllTeams } = useGetTeams()
  const { trigger: addTeamToSeason } = useAddTeamToSeason()

  const [selectedSeason, setSelectedSeason] = useState<Season | null>(null)
  const [confirmDelete, setConfirmDelete] = useState<Season | null>(null)

  // Season form
  const [showCreateForm, setShowCreateForm] = useState(false)
  const [seasonName, setSeasonName] = useState('')
  const [seasonYear, setSeasonYear] = useState('')
  const [hasGroups, setHasGroups] = useState(false)

  // Group editing
  const [editingGroup, setEditingGroup] = useState<(Group & { color?: string }) | null>(null)
  const [editGroupName, setEditGroupName] = useState('')
  const [editGroupColor, setEditGroupColor] = useState('#38bdf8')

  // Bulk create groups
  const [showBulkGroups, setShowBulkGroups] = useState(false)
  const [bulkCount, setBulkCount] = useState('2')

  // Add team
  const [showAddTeamForm, setShowAddTeamForm] = useState(false)
  const [addTeamId, setAddTeamId] = useState('')
  const [addGroupId, setAddGroupId] = useState('')

  const canEdit = appUser?.role === 'administrator'

  useEffect(() => { triggerSeasons(); triggerAllTeams({}) }, [])
  useEffect(() => {
    if (selectedSeason?.has_groups) triggerGroups({ season_id: selectedSeason.id })
  }, [selectedSeason?.id])

  const seasons = (seasonsData as Season[] | undefined) ?? []
  const groups = (groupsData as (Group & { color?: string })[] | undefined) ?? []
  const allTeams = (allTeamsData as Team[] | undefined) ?? []

  async function handleCreateSeason() {
    if (!seasonName.trim()) return
    await createSeason({ name: seasonName, year: seasonYear, has_groups: hasGroups })
    setShowCreateForm(false); setSeasonName(''); setSeasonYear(''); setHasGroups(false)
    triggerSeasons(); refreshSeasons()
  }

  async function handleDelete(s: Season) {
    await deleteSeason({ id: s.id })
    if (selectedSeason?.id === s.id) setSelectedSeason(null)
    setConfirmDelete(null); triggerSeasons(); refreshSeasons()
  }

  async function handleToggleStatus(s: Season) {
    await updateSeason({ id: s.id, status: s.status === 'active' ? 'finished' : 'active' })
    triggerSeasons(); refreshSeasons()
  }

  async function handleSaveGroup() {
    if (!editingGroup) return
    await updateGroup({ id: editingGroup.id, name: editGroupName, color: editGroupColor })
    setEditingGroup(null)
    if (selectedSeason) triggerGroups({ season_id: selectedSeason.id })
  }

  async function handleDeleteGroup(id: number) {
    await deleteGroup({ id })
    if (selectedSeason) triggerGroups({ season_id: selectedSeason.id })
  }

  async function handleBulkCreateGroups() {
    if (!selectedSeason) return
    const n = parseInt(bulkCount)
    if (isNaN(n) || n < 1) return
    const letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
    const colors = ['#38bdf8','#f59e0b','#22c55e','#a855f7','#f97316','#ec4899','#ef4444','#6366f1']
    for (let i = 0; i < n; i++) {
      const name = (letters[i] ?? String(i + 1))
      await createGroup({ season_id: selectedSeason.id, name, color: colors[i % colors.length] ?? '#38bdf8' })
    }
    setShowBulkGroups(false)
    triggerGroups({ season_id: selectedSeason.id })
    triggerSeasons()
  }

  async function handleAddTeam() {
    if (!addTeamId || !selectedSeason) return
    await addTeamToSeason({ team_id: parseInt(addTeamId), season_id: selectedSeason.id, ...(addGroupId ? { group_id: parseInt(addGroupId) } : {}) })
    setAddTeamId(''); setAddGroupId(''); setShowAddTeamForm(false)
    triggerSeasons()
  }

  return (
    <div className="p-6 max-w-5xl mx-auto">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <Calendar className="w-6 h-6 text-primary" />
          <h1 className="text-2xl font-bold text-foreground">Temporadas</h1>
        </div>
        {canEdit && (
          <Button size="sm" onClick={() => setShowCreateForm(true)}>
            <Plus className="w-4 h-4 mr-1" /> Nueva Temporada
          </Button>
        )}
      </div>

      {loading ? (
        <div className="text-center py-12 text-muted-foreground">Cargando...</div>
      ) : (
        <div className="grid gap-4 grid-cols-1 lg:grid-cols-3">
          {/* Seasons list */}
          <div className="space-y-3">
            {seasons.map(s => (
              <div key={s.id} onClick={() => setSelectedSeason(selectedSeason?.id === s.id ? null : s)}
                className={cn('bg-card border rounded-xl p-4 cursor-pointer hover:border-primary/50 transition-all',
                  selectedSeason?.id === s.id ? 'border-primary shadow-sm' : 'border-border')}>
                <div className="flex items-start justify-between">
                  <div>
                    <h3 className="font-bold text-foreground">{s.name}</h3>
                    {s.year && <p className="text-xs text-muted-foreground mt-0.5">Temporada {s.year}</p>}
                  </div>
                  <span className={cn('text-xs px-2 py-0.5 rounded-full font-medium', STATUS_COLORS[s.status] ?? STATUS_COLORS['finished'])}>
                    {s.status === 'active' ? 'Activa' : 'Finalizada'}
                  </span>
                </div>
                <div className="flex items-center gap-3 mt-3 text-xs text-muted-foreground">
                  <span className="flex items-center gap-1"><Users className="w-3.5 h-3.5" />{s.team_count} equipos</span>
                  <span>{s.match_count} partidos</span>
                  {s.has_groups && <span className="flex items-center gap-1"><Layers className="w-3.5 h-3.5" />Grupos</span>}
                </div>
                {canEdit && (
                  <div className="mt-3 pt-3 border-t border-border flex items-center gap-3">
                    <button onClick={e => { e.stopPropagation(); handleToggleStatus(s) }} className="text-xs text-primary hover:underline">
                      {s.status === 'active' ? 'Marcar finalizada' : 'Reactivar'}
                    </button>
                    <button onClick={e => { e.stopPropagation(); setConfirmDelete(s) }}
                      className="text-xs text-red-500 hover:underline flex items-center gap-1 ml-auto">
                      <Trash2 className="w-3 h-3" /> Eliminar
                    </button>
                  </div>
                )}
              </div>
            ))}
          </div>

          {/* Season detail */}
          {selectedSeason && (
            <div className="lg:col-span-2 space-y-4">
              <div className="bg-card border border-border rounded-xl p-4">
                <h2 className="font-bold text-foreground text-lg mb-1">{selectedSeason.name}</h2>
                <div className="flex items-center gap-3 text-sm text-muted-foreground">
                  <span>{selectedSeason.team_count} equipos · {selectedSeason.match_count} partidos</span>
                  {selectedSeason.has_groups && <span className="flex items-center gap-1"><Layers className="w-4 h-4" />Con grupos</span>}
                </div>
              </div>

              {/* Groups management */}
              {selectedSeason.has_groups && (
                <div className="bg-card border border-border rounded-xl overflow-hidden">
                  <div className="flex items-center justify-between px-4 py-3 border-b border-border">
                    <h3 className="font-semibold text-sm text-foreground">Grupos</h3>
                    {canEdit && (
                      <div className="flex gap-2">
                        <Button size="sm" variant="outline" onClick={() => setShowBulkGroups(true)}>
                          <Layers className="w-3.5 h-3.5 mr-1" /> Crear varios
                        </Button>
                        <Button size="sm" variant="outline" onClick={() => {
                          setEditingGroup({ id: -1, season_id: selectedSeason.id, name: '', team_count: 0, color: '#38bdf8' })
                          setEditGroupName(''); setEditGroupColor('#38bdf8')
                        }}>
                          <Plus className="w-3.5 h-3.5 mr-1" /> Grupo
                        </Button>
                      </div>
                    )}
                  </div>

                  {groups.length === 0 ? (
                    <div className="px-4 py-8 text-center text-muted-foreground text-sm">
                      <Layers className="w-8 h-8 mx-auto mb-2 opacity-30" />
                      <p>No hay grupos todavía</p>
                      {canEdit && <button onClick={() => setShowBulkGroups(true)} className="mt-1 text-primary text-xs hover:underline">Crear grupos rápidamente</button>}
                    </div>
                  ) : (
                    <div>
                      {groups.map(g => (
                        <GroupRow key={g.id} group={g} canEdit={canEdit}
                          onEdit={g => { setEditingGroup(g); setEditGroupName(g.name); setEditGroupColor(g.color ?? '#38bdf8') }}
                          onDelete={handleDeleteGroup} />
                      ))}
                    </div>
                  )}
                </div>
              )}

              {/* Add team to season */}
              {canEdit && (
                <div className="bg-card border border-border rounded-xl p-4">
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="font-semibold text-sm text-foreground">Añadir equipo a temporada</h3>
                    <Button size="sm" variant="outline" onClick={() => setShowAddTeamForm(true)}>
                      <Plus className="w-3.5 h-3.5 mr-1" /> Añadir
                    </Button>
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Registra equipos existentes en esta temporada.
                    {selectedSeason.has_groups && ' Puedes asignarlos a un grupo.'}
                  </p>
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* Create season dialog */}
      <Dialog open={showCreateForm} onOpenChange={setShowCreateForm}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle>Nueva Temporada</DialogTitle></DialogHeader>
          <div className="space-y-3 mt-2">
            <Input placeholder="Nombre (ej: Liga 2025-26)" value={seasonName} onChange={e => setSeasonName(e.target.value)} />
            <Input placeholder="Año (ej: 2025-26)" value={seasonYear} onChange={e => setSeasonYear(e.target.value)} />
            <label className="flex items-center gap-2 cursor-pointer">
              <input type="checkbox" checked={hasGroups} onChange={e => setHasGroups(e.target.checked)} className="rounded border-input" />
              <span className="text-sm text-foreground">¿Tiene grupos?</span>
            </label>
            <div className="flex gap-2 justify-end pt-2">
              <Button variant="outline" size="sm" onClick={() => setShowCreateForm(false)}>Cancelar</Button>
              <Button size="sm" onClick={handleCreateSeason}>Crear</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Edit/create group dialog */}
      <Dialog open={!!editingGroup} onOpenChange={open => { if (!open) setEditingGroup(null) }}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>{editingGroup?.id === -1 ? 'Nuevo Grupo' : `Editar Grupo ${editingGroup?.name}`}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 mt-2">
            <div>
              <label className="text-xs text-muted-foreground mb-1 block">Nombre del grupo</label>
              <Input placeholder="Ej: A, Norte, Premier..." value={editGroupName} onChange={e => setEditGroupName(e.target.value)} />
            </div>
            <div>
              <label className="text-xs text-muted-foreground mb-2 block">Color del grupo</label>
              <div className="flex gap-2 flex-wrap mb-2">
                {PRESET_COLORS.map(c => (
                  <button key={c} onClick={() => setEditGroupColor(c)}
                    className={cn('w-7 h-7 rounded-full transition-all', editGroupColor === c ? 'ring-2 ring-offset-2 ring-foreground scale-110' : '')}
                    style={{ backgroundColor: c }} />
                ))}
              </div>
              <div className="flex items-center gap-2">
                <input type="color" value={editGroupColor} onChange={e => setEditGroupColor(e.target.value)}
                  className="w-8 h-8 rounded cursor-pointer border border-border" />
                <span className="text-sm text-muted-foreground font-mono">{editGroupColor}</span>
              </div>
            </div>
            <div className="flex gap-2 justify-end pt-1">
              <Button variant="outline" size="sm" onClick={() => setEditingGroup(null)}>Cancelar</Button>
              <Button size="sm" onClick={async () => {
                if (editingGroup?.id === -1 && selectedSeason) {
                  await createGroup({ season_id: selectedSeason.id, name: editGroupName, color: editGroupColor })
                  setEditingGroup(null)
                  triggerGroups({ season_id: selectedSeason.id })
                } else {
                  await handleSaveGroup()
                }
              }}>
                <Check className="w-4 h-4 mr-1" /> Guardar
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Bulk create groups dialog */}
      <Dialog open={showBulkGroups} onOpenChange={setShowBulkGroups}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle>Crear grupos rápidamente</DialogTitle></DialogHeader>
          <div className="space-y-3 mt-2">
            <div>
              <label className="text-xs text-muted-foreground mb-1 block">¿Cuántos grupos?</label>
              <Input type="number" min="1" max="16" value={bulkCount} onChange={e => setBulkCount(e.target.value)} className="w-24" />
            </div>
            <p className="text-xs text-muted-foreground">
              Se crearán grupos con letras: {
                Array.from({ length: Math.min(parseInt(bulkCount) || 0, 8) }, (_, i) => 'ABCDEFGH'[i]).join(', ')
              }{parseInt(bulkCount) > 8 ? '...' : ''}
            </p>
            <div className="flex gap-2 justify-end pt-2">
              <Button variant="outline" size="sm" onClick={() => setShowBulkGroups(false)}>Cancelar</Button>
              <Button size="sm" onClick={handleBulkCreateGroups}>
                <Plus className="w-4 h-4 mr-1" /> Crear {bulkCount} grupos
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Add team to season dialog */}
      <Dialog open={showAddTeamForm} onOpenChange={setShowAddTeamForm}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle>Añadir Equipo a Temporada</DialogTitle></DialogHeader>
          <div className="space-y-3 mt-2">
            <select value={addTeamId} onChange={e => setAddTeamId(e.target.value)}
              className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm text-foreground">
              <option value="">Seleccionar equipo...</option>
              {allTeams.map(t => <option key={t.id} value={t.id}>{t.name}</option>)}
            </select>
            {selectedSeason?.has_groups && groups.length > 0 && (
              <select value={addGroupId} onChange={e => setAddGroupId(e.target.value)}
                className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm text-foreground">
                <option value="">Sin grupo (opcional)</option>
                {groups.map(g => <option key={g.id} value={g.id}>Grupo {g.name}</option>)}
              </select>
            )}
            <div className="flex gap-2 justify-end pt-2">
              <Button variant="outline" size="sm" onClick={() => setShowAddTeamForm(false)}>Cancelar</Button>
              <Button size="sm" onClick={handleAddTeam}><Check className="w-4 h-4 mr-1" /> Añadir</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Delete confirmation */}
      <Dialog open={!!confirmDelete} onOpenChange={open => { if (!open) setConfirmDelete(null) }}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle>¿Eliminar temporada?</DialogTitle></DialogHeader>
          <div className="mt-2 space-y-4">
            <p className="text-sm text-muted-foreground">
              Vas a eliminar <span className="font-semibold text-foreground">{confirmDelete?.name}</span>.
              Se borrarán también todos sus partidos, grupos y estadísticas.
            </p>
            <div className="flex gap-2 justify-end">
              <Button variant="outline" size="sm" onClick={() => setConfirmDelete(null)}>Cancelar</Button>
              <Button size="sm" variant="destructive" onClick={() => confirmDelete && handleDelete(confirmDelete)}>
                <Trash2 className="w-4 h-4 mr-1" /> Eliminar
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
