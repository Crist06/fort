import { useEffect, useState } from 'react'
import { Trophy, MapPin, Plus } from 'lucide-react'
import { useGetMatches, useCreateMatch } from '../hooks/backend/matches'
import { useGetGroups } from '../hooks/backend/seasons'
import { useGetTeams } from '../hooks/backend/teams'
import { useAppContext } from '../context/AppContext'
import type { Match, Group, Team } from '../types'
import { MatchDetail } from './ui/MatchDetail'
import { Input } from '../lib/shadcn/input'
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '../lib/shadcn/dialog'
import { Button } from '../lib/shadcn/button'

const GROUP_COLORS = ['#00d4ff', '#f59e0b', '#a855f7', '#22c55e', '#f97316', '#ec4899']

function formatTime(dateStr: string | null) {
  if (!dateStr) return null
  return new Date(dateStr).toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' })
}

function TeamShield({ logo, name, color }: { logo: string | null; name: string; color: string }) {
  return (
    <div className="w-9 h-9 rounded-full flex items-center justify-center text-xs font-black text-white flex-shrink-0"
      style={{ background: logo ? 'transparent' : `${color}30`, border: `1px solid ${color}50` }}>
      {logo
        ? <img src={logo} className="w-full h-full rounded-full object-cover" alt={name} />
        : <span style={{ color }}>{name.slice(0, 1)}</span>
      }
    </div>
  )
}

function MatchRow({ match, onClick }: { match: Match; onClick: () => void }) {
  const isFinished = match.status === 'finished'
  const isLive = match.status === 'live'
  const time = formatTime(match.match_date)

  return (
    <div onClick={onClick}
      className="flex items-center gap-2 px-3 py-2.5 cursor-pointer transition-all hover:opacity-90 group"
      style={{ borderBottom: '1px solid rgba(255,255,255,0.04)' }}>

      {/* Home team */}
      <div className="flex-1 flex items-center gap-2 justify-end min-w-0">
        <span className="font-black uppercase text-white/80 text-xs tracking-wide truncate text-right group-hover:text-white">
          {match.home_team_name}
        </span>
        <TeamShield logo={match.home_team_logo} name={match.home_team_name} color={match.home_color} />
      </div>

      {/* Center block */}
      <div className="flex-shrink-0 w-[100px]">
        {isFinished ? (
          <div className="flex items-center justify-center gap-1 px-2 py-2 rounded-lg"
            style={{ background: '#1a2540', border: '1px solid #1e3a5f' }}>
            <span className="font-black text-white text-base w-5 text-center">{match.home_score}</span>
            <span className="text-white/30 font-bold">-</span>
            <span className="font-black text-white text-base w-5 text-center">{match.away_score}</span>
          </div>
        ) : (
          <div className="text-center px-2 py-1.5 rounded-lg" style={{ background: '#1a2540', border: '1px solid #1e3a5f' }}>
            <div className={`font-black text-sm ${isLive ? 'animate-pulse' : ''}`}
              style={{ color: isLive ? '#22c55e' : '#38bdf8' }}>
              {isLive ? '● EN VIVO' : (time ?? 'Por confirmar')}
            </div>
            {match.location && (
              <div className="flex items-center justify-center gap-0.5 mt-0.5">
                <MapPin className="w-2.5 h-2.5 flex-shrink-0" style={{ color: '#38bdf840' }} />
                <span className="text-[9px] uppercase tracking-wide truncate max-w-[80px]" style={{ color: '#38bdf860' }}>
                  {match.location}
                </span>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Away team */}
      <div className="flex-1 flex items-center gap-2 min-w-0">
        <TeamShield logo={match.away_team_logo} name={match.away_team_name} color={match.away_color} />
        <span className="font-black uppercase text-white/80 text-xs tracking-wide truncate group-hover:text-white">
          {match.away_team_name}
        </span>
      </div>
    </div>
  )
}

export default function Partidos() {
  const { activeSeason, appUser } = useAppContext()
  const { data: matchesData, loading, trigger: triggerMatches } = useGetMatches()
  const { data: groupsData, trigger: triggerGroups } = useGetGroups()
  const { data: teamsData, trigger: triggerTeams } = useGetTeams()
  const { trigger: createMatch } = useCreateMatch()

  const [activeRound, setActiveRound] = useState<number | null>(null)
  const [selectedMatch, setSelectedMatch] = useState<Match | null>(null)
  const [showCreate, setShowCreate] = useState(false)
  const [homeTeamId, setHomeTeamId] = useState('')
  const [awayTeamId, setAwayTeamId] = useState('')
  const [matchDate, setMatchDate] = useState('')
  const [location, setLocation] = useState('')
  const [round, setRound] = useState('')

  const canEdit = ['administrator', 'captain', 'referee'].includes(appUser?.role ?? '')

  useEffect(() => {
    if (!activeSeason) return
    triggerMatches({ season_id: activeSeason.id })
    if (activeSeason.has_groups) triggerGroups({ season_id: activeSeason.id })
    triggerTeams({ season_id: activeSeason.id })
  }, [activeSeason?.id])

  const allMatches = (matchesData as Match[] | undefined) ?? []
  const groups = (groupsData as Group[] | undefined) ?? []
  const teams = (teamsData as Team[] | undefined) ?? []
  const rounds = [...new Set(allMatches.map(m => m.round ?? 0))].sort((a, b) => a - b)
  const displayRound = activeRound ?? rounds[0] ?? null
  const filtered = displayRound !== null ? allMatches.filter(m => (m.round ?? 0) === displayRound) : allMatches

  async function handleCreate() {
    if (!homeTeamId || !awayTeamId || !activeSeason) return
    await createMatch({
      season_id: activeSeason.id,
      home_team_id: parseInt(homeTeamId),
      away_team_id: parseInt(awayTeamId),
      match_date: matchDate || undefined,
      location: location || undefined,
      round: round ? parseInt(round) : undefined,
    })
    setShowCreate(false)
    setHomeTeamId(''); setAwayTeamId(''); setMatchDate(''); setLocation(''); setRound('')
    triggerMatches({ season_id: activeSeason.id })
  }

  const groupsWithMatches = groups.length > 0
    ? groups.map((g, i) => ({ group: g, color: GROUP_COLORS[i % GROUP_COLORS.length] ?? '#38bdf8', matches: filtered.filter(m => m.group_id === g.id) }))
    : null

  return (
    <div className="min-h-full" style={{ background: '#060c1a' }}>
      {/* League header */}
      <div className="px-5 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl flex items-center justify-center" style={{ background: '#f59e0b' }}>
            <Trophy className="w-6 h-6 text-black" />
          </div>
          <div>
            <h1 className="font-black uppercase text-white text-xl leading-tight">
              {activeSeason?.name ?? 'Liga'}
            </h1>
            <p className="text-xs font-bold uppercase tracking-widest" style={{ color: '#38bdf8' }}>
              Jornadas
            </p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <div className="text-right">
            <p className="text-xs font-semibold uppercase tracking-widest" style={{ color: '#f59e0b' }}>Temporada</p>
            <p className="font-black text-white text-sm">{activeSeason?.year ?? '—'}</p>
          </div>
          {canEdit && (
            <button onClick={() => setShowCreate(true)}
              className="flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-bold"
              style={{ background: 'rgba(56,189,248,0.15)', color: '#38bdf8', border: '1px solid rgba(56,189,248,0.3)' }}>
              <Plus className="w-3.5 h-3.5" /> Partido
            </button>
          )}
        </div>
      </div>

      {/* Gold separator */}
      <div className="h-0.5 mx-4" style={{ background: 'linear-gradient(90deg, #f59e0b, #38bdf8, transparent)' }} />

      {/* Round selector */}
      {rounds.length > 0 && (
        <div className="flex gap-2 px-4 py-3 overflow-x-auto">
          {rounds.map(r => (
            <button key={r} onClick={() => setActiveRound(displayRound === r && activeRound !== null ? null : r)}
              className="flex-shrink-0 px-4 py-1.5 rounded-full text-xs font-black uppercase tracking-wide transition-all"
              style={displayRound === r
                ? { background: '#38bdf8', color: '#0a0f1e' }
                : { background: 'rgba(56,189,248,0.08)', color: '#38bdf880', border: '1px solid rgba(56,189,248,0.15)' }
              }>
              Jornada {r}
            </button>
          ))}
        </div>
      )}

      {loading && <p className="text-center py-16 text-white/30 text-sm">Cargando partidos...</p>}

      {/* Matches */}
      {!loading && (
        <div className="px-4 pb-6">
          {groupsWithMatches ? (
            /* With groups: 2-column layout */
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              {groupsWithMatches.map(({ group, color, matches }) => (
                <div key={group.id} className="rounded-xl overflow-hidden" style={{ background: '#0d1424', border: '1px solid #1a2b45' }}>
                  {/* Group header */}
                  <div className="flex items-center justify-center py-2.5 font-black uppercase text-sm tracking-widest"
                    style={{ background: color, color: color === '#f59e0b' ? '#0a0f1e' : '#0a0f1e' }}>
                    ◆ {group.name} ◆
                  </div>
                  {matches.length === 0
                    ? <p className="text-center py-8 text-xs" style={{ color: '#38bdf840' }}>Sin partidos</p>
                    : matches.map(m => <MatchRow key={m.id} match={m} onClick={() => setSelectedMatch(m)} />)
                  }
                </div>
              ))}
            </div>
          ) : (
            /* Without groups: single panel */
            <div className="rounded-xl overflow-hidden max-w-2xl mx-auto" style={{ background: '#0d1424', border: '1px solid #1a2b45' }}>
              {filtered.length === 0
                ? <p className="text-center py-16 text-xs" style={{ color: '#38bdf840' }}>No hay partidos en esta jornada</p>
                : filtered.map(m => <MatchRow key={m.id} match={m} onClick={() => setSelectedMatch(m)} />)
              }
            </div>
          )}
        </div>
      )}

      {/* Match detail modal */}
      {selectedMatch && (
        <MatchDetail
          matchId={selectedMatch.id}
          teamColor={selectedMatch.home_color}
          canEdit={canEdit}
          onClose={() => setSelectedMatch(null)}
        />
      )}

      {/* Create match dialog */}
      <Dialog open={showCreate} onOpenChange={setShowCreate}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle>Nuevo Partido</DialogTitle></DialogHeader>
          <div className="space-y-3 mt-2">
            <select value={homeTeamId} onChange={e => setHomeTeamId(e.target.value)}
              className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm text-foreground">
              <option value="">Equipo local...</option>
              {teams.map(t => <option key={t.id} value={t.id}>{t.name}</option>)}
            </select>
            <select value={awayTeamId} onChange={e => setAwayTeamId(e.target.value)}
              className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm text-foreground">
              <option value="">Equipo visitante...</option>
              {teams.map(t => <option key={t.id} value={t.id}>{t.name}</option>)}
            </select>
            <div className="flex gap-2">
              <Input placeholder="Jornada" type="number" value={round} onChange={e => setRound(e.target.value)} className="w-24" />
              <Input placeholder="Ubicación" value={location} onChange={e => setLocation(e.target.value)} className="flex-1" />
            </div>
            <Input type="datetime-local" value={matchDate} onChange={e => setMatchDate(e.target.value)} />
            <div className="flex gap-2 justify-end pt-2">
              <Button variant="outline" size="sm" onClick={() => setShowCreate(false)}>Cancelar</Button>
              <Button size="sm" onClick={handleCreate}>Crear Partido</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
