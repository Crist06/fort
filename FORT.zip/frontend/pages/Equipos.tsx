import { useEffect, useState } from 'react'
import { ArrowLeft, Plus, Shield, Edit2, UserPlus } from 'lucide-react'
import { useGetTeams, useGetTeam, useCreateTeam, useUpdateTeam } from '../hooks/backend/teams'
import { useCreatePlayer, useUpdatePlayer } from '../hooks/backend/players'
import { useAppContext } from '../context/AppContext'
import type { Team } from '../types'
import { PlayerCard } from './ui/PlayerCard'
import type { PlayerWithStats } from './ui/PlayerCard'
import { PlayerModal } from './ui/PlayerModal'
import { EditPlayerForm } from './ui/EditPlayerForm'
import { Button } from '../lib/shadcn/button'
import { Input } from '../lib/shadcn/input'
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '../lib/shadcn/dialog'

// ─── Teams grid ────────────────────────────────────────────────────────────────
function TeamGridCard({ team, onClick }: { team: Team; onClick: () => void }) {
  return (
    <div onClick={onClick}
      className="bg-card border border-border rounded-xl overflow-hidden cursor-pointer hover:border-primary/50 hover:shadow-lg transition-all group">
      <div className="h-20 flex items-center justify-center relative"
        style={{ background: `linear-gradient(135deg, ${team.primary_color}33, ${team.primary_color}11)` }}>
        <div className="w-14 h-14 rounded-full border-2 border-white/20 overflow-hidden bg-muted flex items-center justify-center"
          style={{ boxShadow: `0 4px 20px ${team.primary_color}40` }}>
          {team.logo_url
            ? <img src={team.logo_url} className="w-full h-full object-cover" alt={team.name} />
            : <Shield className="w-6 h-6 text-muted-foreground" />
          }
        </div>
      </div>
      <div className="p-3 text-center">
        <p className="font-bold text-foreground text-sm truncate">{team.name}</p>
        <p className="text-xs text-muted-foreground mt-0.5">{team.player_count ?? 0} jugadores</p>
      </div>
      <div className="h-1" style={{ background: team.primary_color }} />
    </div>
  )
}

// ─── Team detail (dark themed) ─────────────────────────────────────────────────
function TeamDetail({
  teamId, seasonId, canEdit, onBack,
}: { teamId: number; seasonId: number | undefined; canEdit: boolean; onBack: () => void }) {
  const { data: teamData, trigger: triggerTeam } = useGetTeam()
  const { trigger: updateTeam } = useUpdateTeam()
  const { trigger: createPlayer } = useCreatePlayer()
  const { trigger: updatePlayer } = useUpdatePlayer()

  const [selectedPlayer, setSelectedPlayer] = useState<PlayerWithStats | null>(null)
  const [editingPlayer, setEditingPlayer] = useState<PlayerWithStats | null>(null)
  const [showEditTeam, setShowEditTeam] = useState(false)
  const [showAddPlayer, setShowAddPlayer] = useState(false)

  // Team edit state
  const [teamNameEdit, setTeamNameEdit] = useState('')
  const [logoUrl, setLogoUrl] = useState('')
  const [coachName, setCoachName] = useState('')
  const [coachPhoto, setCoachPhoto] = useState('')

  // New player state
  const [newName, setNewName] = useState('')
  const [newNickname, setNewNickname] = useState('')
  const [newNumber, setNewNumber] = useState('')
  const [newPosition, setNewPosition] = useState('')

  useEffect(() => {
    triggerTeam({ team_id: teamId, ...(seasonId ? { season_id: seasonId } : {}) })
  }, [teamId, seasonId])

  const raw = teamData as (Team & { players: PlayerWithStats[]; coach_name: string | null; coach_photo: string | null }) | undefined
  if (!raw) return <div className="p-10 text-center" style={{ color: '#38bdf8' }}>Cargando...</div>

  const players: PlayerWithStats[] = raw.players ?? []
  const teamColor = raw.primary_color ?? '#38bdf8'

  function openEditTeam() {
    setTeamNameEdit(raw?.name ?? '')
    setLogoUrl(raw?.logo_url ?? '')
    setCoachName((raw as { coach_name?: string | null }).coach_name ?? '')
    setCoachPhoto((raw as { coach_photo?: string | null }).coach_photo ?? '')
    setShowEditTeam(true)
  }

  async function handleSaveTeam() {
    await updateTeam({
      team_id: teamId,
      name: teamNameEdit || undefined,
      logo_url: logoUrl || undefined,
      coach_name: coachName || undefined,
      coach_photo: coachPhoto || undefined,
    })
    triggerTeam({ team_id: teamId, ...(seasonId ? { season_id: seasonId } : {}) })
    setShowEditTeam(false)
  }

  async function handleSavePlayer(data: { player_id: number; name: string; nickname: string; number: string; position: string; photo_url: string; birth_date: string }) {
    await updatePlayer({
      player_id: data.player_id,
      name: data.name || undefined,
      nickname: data.nickname || undefined,
      number: data.number ? parseInt(data.number) : undefined,
      position: data.position || undefined,
      photo_url: data.photo_url || undefined,
      birth_date: data.birth_date || undefined,
    })
    setEditingPlayer(null)
    triggerTeam({ team_id: teamId, ...(seasonId ? { season_id: seasonId } : {}) })
  }

  async function handleAddPlayer() {
    if (!newName.trim()) return
    await createPlayer({
      team_id: teamId,
      name: newName,
      nickname: newNickname || undefined,
      number: newNumber ? parseInt(newNumber) : undefined,
      position: newPosition || undefined,
    })
    setNewName(''); setNewNickname(''); setNewNumber(''); setNewPosition('')
    setShowAddPlayer(false)
    triggerTeam({ team_id: teamId, ...(seasonId ? { season_id: seasonId } : {}) })
  }

  const coachData = raw as { coach_name?: string | null; coach_photo?: string | null }

  return (
    <div className="min-h-full rounded-xl overflow-hidden" style={{ background: '#0a0f1e' }}>
      {/* Header band */}
      <div className="h-1" style={{ background: `linear-gradient(90deg, ${teamColor}, transparent)` }} />

      <div className="p-4 md:p-6">
        {/* Top nav */}
        <div className="flex items-center justify-between mb-6">
          <button onClick={onBack} className="flex items-center gap-2 text-sm font-medium transition-colors hover:opacity-80"
            style={{ color: '#38bdf8' }}>
            <ArrowLeft className="w-4 h-4" /> Todos los equipos
          </button>
          {canEdit && (
            <div className="flex gap-2">
              <button onClick={openEditTeam}
                className="flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-lg font-medium transition-colors"
                style={{ background: 'rgba(56,189,248,0.1)', color: '#38bdf8', border: '1px solid rgba(56,189,248,0.2)' }}>
                <Edit2 className="w-3.5 h-3.5" /> Editar equipo
              </button>
              <button onClick={() => setShowAddPlayer(true)}
                className="flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-lg font-medium transition-colors"
                style={{ background: teamColor, color: '#0a0f1e' }}>
                <UserPlus className="w-3.5 h-3.5" /> Añadir jugador
              </button>
            </div>
          )}
        </div>

        <div className="flex flex-col lg:flex-row gap-6">
          {/* Left panel */}
          <div className="lg:w-48 flex-shrink-0 flex flex-col items-center gap-4">
            {/* Shield */}
            <div className="w-40 h-40 rounded-full flex items-center justify-center"
              style={{ border: `2px dashed ${teamColor}60`, background: '#0d1424' }}>
              {raw.logo_url
                ? <img src={raw.logo_url} className="w-32 h-32 rounded-full object-cover" alt={raw.name} />
                : <Shield className="w-16 h-16" style={{ color: `${teamColor}50` }} />
              }
            </div>
            <div className="text-center">
              <p className="font-black uppercase text-white text-lg tracking-wider">{raw.name}</p>
              <p className="text-xs uppercase tracking-widest mt-1" style={{ color: teamColor }}>
                {players.length} jugadores
              </p>
            </div>

            {/* Coach */}
            {coachData.coach_name && (
              <div className="w-full rounded-xl p-3 flex items-center gap-3 mt-auto"
                style={{ background: '#111e35', border: '1px solid #1e3a5f' }}>
                <div className="w-10 h-10 rounded-lg overflow-hidden flex-shrink-0"
                  style={{ background: '#0d1829', border: '1px solid #1e3a5f' }}>
                  {coachData.coach_photo
                    ? <img src={coachData.coach_photo} className="w-full h-full object-cover" alt="" />
                    : <div className="w-full h-full flex items-center justify-center">
                        <Shield className="w-5 h-5" style={{ color: '#38bdf8' }} />
                      </div>
                  }
                </div>
                <div>
                  <p className="text-[10px] font-semibold uppercase tracking-wider" style={{ color: '#38bdf8' }}>
                    Director Técnico
                  </p>
                  <p className="text-white text-xs font-bold mt-0.5 uppercase">{coachData.coach_name}</p>
                </div>
              </div>
            )}
          </div>

          {/* Player grid */}
          <div className="flex-1">
            {players.length === 0 ? (
              <div className="flex items-center justify-center h-40 rounded-xl"
                style={{ border: `1px dashed ${teamColor}30`, color: `${teamColor}60` }}>
                <p className="text-sm font-medium">Sin jugadores registrados</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {players.map(p => (
                  <PlayerCard
                    key={p.id}
                    player={p}
                    canEdit={canEdit}
                    onClick={() => setSelectedPlayer(p)}
                    onEdit={e => { e.stopPropagation(); setEditingPlayer(p) }}
                  />
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Player profile modal */}
      {selectedPlayer && (
        <PlayerModal
          player={selectedPlayer}
          teamColor={teamColor}
          onClose={() => setSelectedPlayer(null)}
        />
      )}

      {/* Edit player modal */}
      <EditPlayerForm
        player={editingPlayer}
        open={!!editingPlayer}
        onClose={() => setEditingPlayer(null)}
        onSave={handleSavePlayer}
      />

      {/* Edit team dialog */}
      <Dialog open={showEditTeam} onOpenChange={setShowEditTeam}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle>Editar Equipo</DialogTitle></DialogHeader>
          <div className="space-y-3 mt-2">
            <div>
              <label className="text-xs text-muted-foreground mb-1 block">Nombre del equipo</label>
              <Input value={teamNameEdit} onChange={e => setTeamNameEdit(e.target.value)} placeholder="Nombre del equipo" />
            </div>
            <div>
              <label className="text-xs text-muted-foreground mb-1 block">URL del escudo / logo</label>
              <Input value={logoUrl} onChange={e => setLogoUrl(e.target.value)} placeholder="https://..." />
              {logoUrl && <img src={logoUrl} className="mt-2 w-12 h-12 rounded-full object-cover border border-border" alt="preview" />}
            </div>
            <div>
              <label className="text-xs text-muted-foreground mb-1 block">Nombre del entrenador</label>
              <Input value={coachName} onChange={e => setCoachName(e.target.value)} placeholder="Nombre y apellidos" />
            </div>
            <div>
              <label className="text-xs text-muted-foreground mb-1 block">URL foto entrenador</label>
              <Input value={coachPhoto} onChange={e => setCoachPhoto(e.target.value)} placeholder="https://..." />
            </div>
            <div className="flex gap-2 justify-end pt-2">
              <Button variant="outline" size="sm" onClick={() => setShowEditTeam(false)}>Cancelar</Button>
              <Button size="sm" onClick={handleSaveTeam}>Guardar</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Add player dialog */}
      <Dialog open={showAddPlayer} onOpenChange={setShowAddPlayer}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle>Añadir Jugador</DialogTitle></DialogHeader>
          <div className="space-y-3 mt-2">
            <Input placeholder="Nombre completo *" value={newName} onChange={e => setNewName(e.target.value)} />
            <Input placeholder="Apodo (opcional)" value={newNickname} onChange={e => setNewNickname(e.target.value)} />
            <div className="flex gap-2">
              <Input placeholder="Dorsal" type="number" value={newNumber} onChange={e => setNewNumber(e.target.value)} className="w-24" />
              <select value={newPosition} onChange={e => setNewPosition(e.target.value)}
                className="flex-1 rounded-md border border-input bg-background px-3 py-2 text-sm text-foreground">
                <option value="">Posición...</option>
                {['Portero','Defensa','Mediocampista','Delantero'].map(p => <option key={p} value={p}>{p}</option>)}
              </select>
            </div>
            <div className="flex gap-2 justify-end pt-2">
              <Button variant="outline" size="sm" onClick={() => setShowAddPlayer(false)}>Cancelar</Button>
              <Button size="sm" onClick={handleAddPlayer}><Plus className="w-4 h-4 mr-1" />Añadir</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}

// ─── Main page ─────────────────────────────────────────────────────────────────
export default function Equipos() {
  const { activeSeason, appUser } = useAppContext()
  const { data: teamsData, loading, trigger: triggerTeams } = useGetTeams()
  const { trigger: createTeam } = useCreateTeam()

  const [selectedTeamId, setSelectedTeamId] = useState<number | null>(null)
  const [showCreateTeam, setShowCreateTeam] = useState(false)
  const [teamName, setTeamName] = useState('')
  const [teamColor, setTeamColor] = useState('#3b82f6')

  const canEdit = appUser?.role === 'administrator' || appUser?.role === 'captain'

  useEffect(() => {
    triggerTeams(activeSeason ? { season_id: activeSeason.id } : {})
  }, [activeSeason?.id])

  const teams = (teamsData as Team[] | undefined) ?? []

  async function handleCreateTeam() {
    if (!teamName.trim()) return
    await createTeam({
      name: teamName,
      primary_color: teamColor,
      ...(activeSeason ? { season_id: activeSeason.id } : {}),
    })
    setTeamName(''); setTeamColor('#3b82f6')
    setShowCreateTeam(false)
    triggerTeams(activeSeason ? { season_id: activeSeason.id } : {})
  }

  if (selectedTeamId) {
    return (
      <div className="p-4 md:p-6 max-w-5xl mx-auto">
        <TeamDetail
          teamId={selectedTeamId}
          seasonId={activeSeason?.id}
          canEdit={canEdit}
          onBack={() => setSelectedTeamId(null)}
        />
      </div>
    )
  }

  return (
    <div className="p-6 max-w-5xl mx-auto">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <Shield className="w-6 h-6 text-primary" />
          <div>
            <h1 className="text-2xl font-bold text-foreground">Equipos</h1>
            {activeSeason && <p className="text-sm text-muted-foreground">{activeSeason.name}</p>}
          </div>
        </div>
        {canEdit && (
          <Button size="sm" onClick={() => setShowCreateTeam(true)}>
            <Plus className="w-4 h-4 mr-1" /> Nuevo Equipo
          </Button>
        )}
      </div>

      {loading ? (
        <div className="text-center py-12 text-muted-foreground">Cargando equipos...</div>
      ) : teams.length === 0 ? (
        <div className="text-center py-12 text-muted-foreground">No hay equipos registrados</div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
          {teams.map(team => (
            <TeamGridCard key={team.id} team={team} onClick={() => setSelectedTeamId(team.id)} />
          ))}
        </div>
      )}

      <Dialog open={showCreateTeam} onOpenChange={setShowCreateTeam}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle>Nuevo Equipo</DialogTitle></DialogHeader>
          <div className="space-y-3 mt-2">
            <Input placeholder="Nombre del equipo" value={teamName} onChange={e => setTeamName(e.target.value)} />
            <div>
              <label className="text-xs text-muted-foreground mb-1 block">Color del equipo</label>
              <div className="flex items-center gap-2">
                <input type="color" value={teamColor} onChange={e => setTeamColor(e.target.value)}
                  className="w-10 h-10 rounded cursor-pointer border border-border" />
                <span className="text-sm text-muted-foreground">{teamColor}</span>
              </div>
            </div>
            <div className="flex gap-2 justify-end pt-2">
              <Button variant="outline" size="sm" onClick={() => setShowCreateTeam(false)}>Cancelar</Button>
              <Button size="sm" onClick={handleCreateTeam}>Crear</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
