import { useState, useEffect } from 'react'
import { User, Edit2, Check, Shield, Swords, Star } from 'lucide-react'
import { useUpdateMyProfile } from '../hooks/backend/players'
import { useGetMyMatches } from '../hooks/backend/matches'
import { useAppContext } from '../context/AppContext'
import type { Match } from '../types'
import { Button } from '../lib/shadcn/button'
import { Input } from '../lib/shadcn/input'
import { cn } from '../lib/shadcn/utils'

const ROLE_LABELS: Record<string, string> = {
  player: 'Jugador',
  captain: 'Capitán',
  referee: 'Árbitro',
  administrator: 'Administrador',
}

const ROLE_COLORS: Record<string, string> = {
  player: 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200',
  captain: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200',
  referee: 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200',
  administrator: 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200',
}

export default function Perfil() {
  const { appUser, refreshUser, activeSeason } = useAppContext()
  const { trigger: updateProfile } = useUpdateMyProfile()
  const { data: myMatchesData, trigger: triggerMatches } = useGetMyMatches()

  const [editing, setEditing] = useState(false)
  const [nickname, setNickname] = useState('')
  const [photoUrl, setPhotoUrl] = useState('')
  const [username, setUsername] = useState('')
  const [saved, setSaved] = useState(false)

  useEffect(() => {
    if (appUser) {
      setNickname(appUser.nickname ?? '')
      setPhotoUrl(appUser.photo_url ?? '')
      setUsername(appUser.username ?? '')
    }
  }, [appUser?.id])

  useEffect(() => {
    if (activeSeason && appUser?.player_id) {
      triggerMatches({ season_id: activeSeason.id })
    }
  }, [activeSeason?.id, appUser?.player_id])

  async function handleSave() {
    await updateProfile({
      nickname: nickname || undefined,
      photo_url: photoUrl || undefined,
      username: username || undefined,
    })
    setEditing(false)
    setSaved(true)
    refreshUser()
    setTimeout(() => setSaved(false), 2000)
  }

  const myMatchesResult = myMatchesData as { matches: Match[]; my_team_id: number | null } | undefined
  const myMatches = (myMatchesResult?.matches ?? []).filter(m => m.is_my_match)
  const upcoming = myMatches.filter(m => m.status === 'scheduled').slice(0, 3)
  const recentResults = myMatches.filter(m => m.status === 'finished').slice(-3).reverse()

  const displayName = appUser?.nickname ?? appUser?.username ?? 'Cargando...'
  const role = appUser?.role ?? 'player'

  return (
    <div className="p-6 max-w-3xl mx-auto">
      <div className="flex items-center gap-3 mb-6">
        <User className="w-6 h-6 text-primary" />
        <h1 className="text-2xl font-bold text-foreground">Mi Perfil</h1>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Profile card */}
        <div className="lg:col-span-1">
          <div className="bg-card border border-border rounded-xl overflow-hidden">
            <div className="h-20 bg-gradient-to-br from-primary/30 to-primary/10" />
            <div className="px-4 pb-4 -mt-10">
              <div className="flex items-end justify-between mb-3">
                <div className="w-20 h-20 rounded-full border-4 border-card overflow-hidden bg-muted flex items-center justify-center">
                  {(editing ? photoUrl : appUser?.photo_url)
                    ? <img src={editing ? photoUrl : appUser?.photo_url!} className="w-full h-full object-cover" alt="" />
                    : <span className="text-2xl font-bold text-foreground/30">
                        {displayName.slice(0, 2).toUpperCase()}
                      </span>
                  }
                </div>
                <button
                  onClick={() => setEditing(!editing)}
                  className="text-muted-foreground hover:text-foreground transition-colors mt-2"
                >
                  <Edit2 className="w-4 h-4" />
                </button>
              </div>

              {!editing ? (
                <div>
                  <h2 className="font-bold text-lg text-foreground">{displayName}</h2>
                  {appUser?.nickname && appUser.username !== appUser.nickname && (
                    <p className="text-sm text-muted-foreground">{appUser.username}</p>
                  )}
                  <p className="text-sm text-muted-foreground">{appUser?.email}</p>
                  <div className="flex flex-wrap gap-2 mt-3">
                    <span className={cn('text-xs px-2 py-1 rounded-full font-medium', ROLE_COLORS[role])}>
                      {ROLE_LABELS[role] ?? role}
                    </span>
                    {appUser?.position && (
                      <span className="text-xs px-2 py-1 rounded-full bg-muted text-muted-foreground">
                        {appUser.position}
                      </span>
                    )}
                    {appUser?.number && (
                      <span className="text-xs px-2 py-1 rounded-full bg-muted text-muted-foreground">
                        #{appUser.number}
                      </span>
                    )}
                  </div>
                  {saved && (
                    <div className="flex items-center gap-1.5 mt-2 text-green-600 text-sm">
                      <Check className="w-4 h-4" /> Perfil guardado
                    </div>
                  )}
                </div>
              ) : (
                <div className="space-y-2">
                  <div>
                    <label className="text-xs text-muted-foreground mb-1 block">Nombre visible</label>
                    <Input placeholder="Tu nombre" value={username} onChange={e => setUsername(e.target.value)} className="h-8 text-sm" />
                  </div>
                  <div>
                    <label className="text-xs text-muted-foreground mb-1 block">Apodo</label>
                    <Input placeholder="Apodo en campo" value={nickname} onChange={e => setNickname(e.target.value)} className="h-8 text-sm" />
                  </div>
                  <div>
                    <label className="text-xs text-muted-foreground mb-1 block">URL de foto</label>
                    <Input placeholder="https://..." value={photoUrl} onChange={e => setPhotoUrl(e.target.value)} className="h-8 text-sm" />
                  </div>
                  <div className="flex gap-2 pt-1">
                    <Button size="sm" variant="outline" className="flex-1 h-8 text-xs" onClick={() => setEditing(false)}>
                      Cancelar
                    </Button>
                    <Button size="sm" className="flex-1 h-8 text-xs" onClick={handleSave}>
                      <Check className="w-3.5 h-3.5 mr-1" /> Guardar
                    </Button>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Stats card */}
          {appUser?.player_id && (
            <div className="bg-card border border-border rounded-xl p-4 mt-4">
              <h3 className="text-sm font-semibold text-foreground mb-3">Equipo</h3>
              <div className="flex items-center gap-2">
                <Shield className="w-4 h-4 text-muted-foreground" />
                <span className="text-sm text-foreground">
                  {appUser.team_id ? `Equipo #${appUser.team_id}` : 'Sin equipo'}
                </span>
              </div>
            </div>
          )}
        </div>

        {/* Matches column */}
        {appUser?.player_id && (
          <div className="lg:col-span-2 space-y-4">
            {/* Upcoming matches */}
            {upcoming.length > 0 && (
              <div className="bg-card border border-border rounded-xl overflow-hidden">
                <div className="px-4 py-3 border-b border-border flex items-center gap-2">
                  <Swords className="w-4 h-4 text-blue-500" />
                  <span className="font-semibold text-sm text-foreground">Próximos partidos</span>
                </div>
                <div className="divide-y divide-border/50">
                  {upcoming.map(m => (
                    <div key={m.id} className="px-4 py-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2 text-sm">
                          <span className="text-foreground font-medium">{m.home_team_name}</span>
                          <span className="text-muted-foreground">vs</span>
                          <span className="text-foreground font-medium">{m.away_team_name}</span>
                        </div>
                        <span className="text-xs bg-blue-100 text-blue-700 dark:bg-blue-900 dark:text-blue-300 px-2 py-0.5 rounded-full">
                          J{m.round}
                        </span>
                      </div>
                      {m.match_date && (
                        <p className="text-xs text-muted-foreground mt-1">
                          {new Date(m.match_date).toLocaleDateString('es-ES', { weekday: 'short', day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}
                        </p>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Recent results */}
            {recentResults.length > 0 && (
              <div className="bg-card border border-border rounded-xl overflow-hidden">
                <div className="px-4 py-3 border-b border-border flex items-center gap-2">
                  <Star className="w-4 h-4 text-yellow-500" />
                  <span className="font-semibold text-sm text-foreground">Últimos resultados</span>
                </div>
                <div className="divide-y divide-border/50">
                  {recentResults.map(m => {
                    const myTeamWon = (appUser.team_id === m.home_team_id && m.home_score > m.away_score)
                      || (appUser.team_id === m.away_team_id && m.away_score > m.home_score)
                    const draw = m.home_score === m.away_score
                    return (
                      <div key={m.id} className="px-4 py-3 flex items-center justify-between">
                        <div className="flex items-center gap-2 text-sm">
                          <span className="text-foreground font-medium">{m.home_team_name}</span>
                          <span className="bg-muted px-2 py-0.5 rounded font-bold text-foreground text-xs">
                            {m.home_score} - {m.away_score}
                          </span>
                          <span className="text-foreground font-medium">{m.away_team_name}</span>
                        </div>
                        <span className={cn('text-xs px-2 py-0.5 rounded-full font-medium',
                          draw ? 'bg-muted text-muted-foreground'
                            : myTeamWon ? 'bg-green-100 text-green-700 dark:bg-green-900 dark:text-green-300'
                            : 'bg-red-100 text-red-700 dark:bg-red-900 dark:text-red-300'
                        )}>
                          {draw ? 'Empate' : myTeamWon ? 'Victoria' : 'Derrota'}
                        </span>
                      </div>
                    )
                  })}
                </div>
              </div>
            )}

            {upcoming.length === 0 && recentResults.length === 0 && (
              <div className="bg-card border border-border rounded-xl p-8 text-center text-muted-foreground text-sm">
                No hay partidos en esta temporada todavía
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  )
}
