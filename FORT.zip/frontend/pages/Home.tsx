import { useEffect } from 'react'
import { Link } from 'react-router-dom'
import { Trophy, Swords, ArrowRight, MapPin, Clock } from 'lucide-react'
import { useGetStandings } from '../hooks/backend/stats'
import { useGetMatches } from '../hooks/backend/matches'
import { useAppContext } from '../context/AppContext'
import type { Standing, Match } from '../types'
import { cn } from '../lib/shadcn/utils'

function TeamColorDot({ color }: { color: string }) {
  return <span className="inline-block w-3 h-3 rounded-full flex-shrink-0" style={{ backgroundColor: color }} />
}

function formatDate(dateStr: string | null) {
  if (!dateStr) return 'Por confirmar'
  const d = new Date(dateStr)
  return d.toLocaleDateString('es-ES', { weekday: 'short', day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })
}

export default function Home() {
  const { activeSeason } = useAppContext()
  const { data: standingsData, trigger: triggerStandings } = useGetStandings()
  const { data: matchesData, trigger: triggerMatches } = useGetMatches()

  useEffect(() => {
    if (activeSeason) {
      triggerStandings({ season_id: activeSeason.id })
      triggerMatches({ season_id: activeSeason.id })
    }
  }, [activeSeason?.id])

  const standings = (standingsData as Standing[] | undefined) ?? []
  const allMatches = (matchesData as Match[] | undefined) ?? []
  const upcoming = allMatches.filter(m => m.status === 'scheduled').slice(0, 4)
  const recent = allMatches.filter(m => m.status === 'finished').slice(-4).reverse()
  const top5 = standings.slice(0, 5)

  return (
    <div className="p-6 max-w-6xl mx-auto space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-foreground">
          {activeSeason ? activeSeason.name : 'Bienvenido'}
        </h1>
        <p className="text-muted-foreground text-sm mt-1">Resumen de la temporada actual</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Standings preview */}
        <div className="lg:col-span-1 bg-card border border-border rounded-xl overflow-hidden">
          <div className="flex items-center justify-between px-4 py-3 border-b border-border">
            <div className="flex items-center gap-2">
              <Trophy className="w-4 h-4 text-yellow-500" />
              <span className="font-semibold text-sm text-foreground">Clasificación</span>
            </div>
            <Link to="/clasificacion" className="text-xs text-primary hover:underline flex items-center gap-1">
              Ver todo <ArrowRight className="w-3 h-3" />
            </Link>
          </div>
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border bg-muted/30">
                <th className="px-3 py-2 text-left text-xs text-muted-foreground font-medium w-6">#</th>
                <th className="px-3 py-2 text-left text-xs text-muted-foreground font-medium">Equipo</th>
                <th className="px-3 py-2 text-center text-xs text-muted-foreground font-medium">PJ</th>
                <th className="px-3 py-2 text-center text-xs text-muted-foreground font-medium">Pts</th>
              </tr>
            </thead>
            <tbody>
              {top5.length === 0 && (
                <tr><td colSpan={4} className="px-3 py-6 text-center text-muted-foreground text-xs">Sin datos</td></tr>
              )}
              {top5.map((s, i) => (
                <tr key={s.id} className="border-b border-border/50 hover:bg-muted/20 transition-colors">
                  <td className="px-3 py-2.5 text-xs text-muted-foreground">{i + 1}</td>
                  <td className="px-3 py-2.5">
                    <div className="flex items-center gap-2">
                      <TeamColorDot color={s.primary_color} />
                      <span className="font-medium text-foreground truncate text-xs">{s.name}</span>
                    </div>
                  </td>
                  <td className="px-3 py-2.5 text-center text-xs text-muted-foreground">{s.played}</td>
                  <td className="px-3 py-2.5 text-center">
                    <span className="font-bold text-sm text-foreground">{s.points}</span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Matches column */}
        <div className="lg:col-span-2 space-y-4">
          {/* Upcoming */}
          <div className="bg-card border border-border rounded-xl overflow-hidden">
            <div className="flex items-center justify-between px-4 py-3 border-b border-border">
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-blue-500" />
                <span className="font-semibold text-sm text-foreground">Próximos Partidos</span>
              </div>
              <Link to="/partidos" className="text-xs text-primary hover:underline flex items-center gap-1">
                Ver todo <ArrowRight className="w-3 h-3" />
              </Link>
            </div>
            <div className="divide-y divide-border/50">
              {upcoming.length === 0 && (
                <p className="px-4 py-6 text-center text-muted-foreground text-sm">No hay partidos programados</p>
              )}
              {upcoming.map(m => (
                <div key={m.id} className="px-4 py-3">
                  <div className="flex items-center gap-3">
                    <div className="flex items-center gap-2 flex-1 min-w-0 justify-end">
                      <span className="font-medium text-sm text-foreground truncate text-right">{m.home_team_name}</span>
                      <TeamColorDot color={m.home_color} />
                    </div>
                    <div className="flex-shrink-0 text-center">
                      <div className="bg-muted rounded px-2 py-1 text-xs font-bold text-foreground">VS</div>
                      <div className="text-xs text-muted-foreground mt-0.5">J{m.round}</div>
                    </div>
                    <div className="flex items-center gap-2 flex-1 min-w-0 justify-start">
                      <TeamColorDot color={m.away_color} />
                      <span className="font-medium text-sm text-foreground truncate">{m.away_team_name}</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 mt-1 justify-center">
                    <span className="text-xs text-muted-foreground">{formatDate(m.match_date)}</span>
                    {m.location && (
                      <span className="flex items-center gap-0.5 text-xs text-muted-foreground">
                        <MapPin className="w-3 h-3" /> {m.location}
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Recent results */}
          <div className="bg-card border border-border rounded-xl overflow-hidden">
            <div className="flex items-center justify-between px-4 py-3 border-b border-border">
              <div className="flex items-center gap-2">
                <Swords className="w-4 h-4 text-green-500" />
                <span className="font-semibold text-sm text-foreground">Últimos Resultados</span>
              </div>
            </div>
            <div className="divide-y divide-border/50">
              {recent.length === 0 && (
                <p className="px-4 py-6 text-center text-muted-foreground text-sm">No hay resultados todavía</p>
              )}
              {recent.map(m => (
                <div key={m.id} className="px-4 py-3">
                  <div className="flex items-center gap-3">
                    <div className="flex items-center gap-2 flex-1 min-w-0 justify-end">
                      <span className={cn('font-medium text-sm truncate text-right',
                        m.home_score > m.away_score ? 'text-foreground' : 'text-muted-foreground'
                      )}>{m.home_team_name}</span>
                      <TeamColorDot color={m.home_color} />
                    </div>
                    <div className="flex-shrink-0 bg-muted rounded px-3 py-1 text-sm font-bold text-foreground min-w-[60px] text-center">
                      {m.home_score} - {m.away_score}
                    </div>
                    <div className="flex items-center gap-2 flex-1 min-w-0 justify-start">
                      <TeamColorDot color={m.away_color} />
                      <span className={cn('font-medium text-sm truncate',
                        m.away_score > m.home_score ? 'text-foreground' : 'text-muted-foreground'
                      )}>{m.away_team_name}</span>
                    </div>
                  </div>
                  <p className="text-xs text-muted-foreground text-center mt-1">Jornada {m.round}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
