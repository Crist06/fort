import { X } from 'lucide-react'
import type { PlayerWithStats } from './PlayerCard'

function StatBox({ value, label, emoji }: { value: number; label: string; emoji: string }) {
  return (
    <div className="flex flex-col items-center justify-center rounded-xl p-3 gap-1"
      style={{ background: '#131e3a', border: '1px solid #1e3a5f' }}>
      <span className="text-xl">{emoji}</span>
      <span className="text-2xl font-black text-white">{value}</span>
      <span className="text-[10px] uppercase tracking-wider font-semibold" style={{ color: '#38bdf8' }}>
        {label}
      </span>
    </div>
  )
}

export function PlayerModal({
  player,
  teamColor,
  onClose,
}: {
  player: PlayerWithStats
  teamColor: string
  onClose: () => void
}) {
  const birthDate = player.birth_date
    ? new Date(player.birth_date).toLocaleDateString('es-ES', { day: '2-digit', month: '2-digit', year: 'numeric' })
    : null

  const age = player.birth_date
    ? Math.floor((Date.now() - new Date(player.birth_date).getTime()) / (365.25 * 24 * 3600 * 1000))
    : null

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      style={{ background: 'rgba(0,0,0,0.85)' }}
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-sm rounded-2xl overflow-hidden"
        style={{ background: 'linear-gradient(160deg, #0d1829 0%, #111e35 100%)', border: '1px solid #1e3a5f' }}
        onClick={e => e.stopPropagation()}
      >
        {/* Top band with team color */}
        <div className="h-1.5 w-full" style={{ background: `linear-gradient(90deg, ${teamColor}, transparent)` }} />

        {/* Close */}
        <button onClick={onClose} className="absolute top-3 right-3 rounded-full p-1.5 transition-colors"
          style={{ background: 'rgba(255,255,255,0.05)' }}>
          <X className="w-4 h-4 text-white" />
        </button>

        {/* Player header */}
        <div className="flex items-center gap-4 p-5 pb-4">
          <div className="relative flex-shrink-0">
            <div className="w-20 h-20 rounded-full overflow-hidden"
              style={{ border: `3px solid ${teamColor}`, boxShadow: `0 0 20px ${teamColor}40` }}>
              {player.photo_url ? (
                <img src={player.photo_url} className="w-full h-full object-cover" alt={player.name} />
              ) : (
                <div className="w-full h-full flex items-center justify-center text-2xl font-black text-white"
                  style={{ background: '#0d1829' }}>
                  {player.name.slice(0, 1)}
                </div>
              )}
            </div>
            {player.number !== null && (
              <div className="absolute -bottom-1 -right-1 w-7 h-7 rounded-full flex items-center justify-center text-xs font-black text-white"
                style={{ background: teamColor }}>
                {player.number}
              </div>
            )}
          </div>

          <div className="flex-1 min-w-0">
            <p className="font-black uppercase text-white text-base leading-tight tracking-wide">
              {player.name}
            </p>
            {player.nickname && (
              <p className="text-sm font-semibold mt-0.5" style={{ color: '#38bdf8' }}>
                &ldquo;{player.nickname}&rdquo;
              </p>
            )}
            {player.position && (
              <p className="text-xs uppercase tracking-widest mt-1 font-semibold" style={{ color: '#38bdf8' }}>
                {player.position}
              </p>
            )}
          </div>

          {player.number !== null && (
            <span className="font-black text-5xl flex-shrink-0 leading-none"
              style={{
                color: 'transparent',
                WebkitTextStroke: `2px ${teamColor}`,
              }}>
              {player.number}
            </span>
          )}
        </div>

        {/* Info row */}
        {(birthDate || age) && (
          <div className="px-5 pb-4 flex gap-4">
            {birthDate && (
              <div className="rounded-lg px-3 py-2" style={{ background: '#131e3a', border: '1px solid #1e3a5f' }}>
                <p className="text-[10px] uppercase tracking-wider font-semibold mb-0.5" style={{ color: '#38bdf8' }}>
                  Nacimiento
                </p>
                <p className="text-sm font-bold text-white">{birthDate}</p>
              </div>
            )}
            {age && (
              <div className="rounded-lg px-3 py-2" style={{ background: '#131e3a', border: '1px solid #1e3a5f' }}>
                <p className="text-[10px] uppercase tracking-wider font-semibold mb-0.5" style={{ color: '#38bdf8' }}>
                  Edad
                </p>
                <p className="text-sm font-bold text-white">{age} años</p>
              </div>
            )}
          </div>
        )}

        {/* Season stats */}
        <div className="px-5 pb-2">
          <p className="text-[10px] uppercase tracking-widest font-semibold mb-3" style={{ color: '#38bdf8' }}>
            Estadísticas de temporada
          </p>
          <div className="grid grid-cols-4 gap-2">
            <StatBox value={player.goals} label="Goles" emoji="⚽" />
            <StatBox value={player.assists} label="Asist." emoji="🎯" />
            <StatBox value={player.yellow_cards} label="Amarillas" emoji="🟡" />
            <StatBox value={player.red_cards} label="Rojas" emoji="🔴" />
          </div>
        </div>

        <div className="h-5" />
      </div>
    </div>
  )
}
