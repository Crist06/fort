import { useState } from 'react'
import { Check } from 'lucide-react'
import { Button } from '../../lib/shadcn/button'
import { Input } from '../../lib/shadcn/input'
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '../../lib/shadcn/dialog'
import type { PlayerWithStats } from './PlayerCard'

const POSITIONS = ['Portero', 'Defensa', 'Mediocampista', 'Delantero']

interface Props {
  player: PlayerWithStats | null
  open: boolean
  onClose: () => void
  onSave: (data: {
    player_id: number
    name: string
    nickname: string
    number: string
    position: string
    photo_url: string
    birth_date: string
  }) => Promise<void>
}

export function EditPlayerForm({ player, open, onClose, onSave }: Props) {
  const [name, setName] = useState(player?.name ?? '')
  const [nickname, setNickname] = useState(player?.nickname ?? '')
  const [number, setNumber] = useState(player?.number?.toString() ?? '')
  const [position, setPosition] = useState(player?.position ?? '')
  const [photoUrl, setPhotoUrl] = useState(player?.photo_url ?? '')
  const [birthDate, setBirthDate] = useState(
    player?.birth_date ? player.birth_date.slice(0, 10) : ''
  )
  const [saving, setSaving] = useState(false)

  // Sync when player changes
  const handleOpen = (open: boolean) => {
    if (open && player) {
      setName(player.name)
      setNickname(player.nickname ?? '')
      setNumber(player.number?.toString() ?? '')
      setPosition(player.position ?? '')
      setPhotoUrl(player.photo_url ?? '')
      setBirthDate(player.birth_date ? player.birth_date.slice(0, 10) : '')
    }
    if (!open) onClose()
  }

  async function handleSave() {
    if (!player || !name.trim()) return
    setSaving(true)
    await onSave({ player_id: player.id, name, nickname, number, position, photo_url: photoUrl, birth_date: birthDate })
    setSaving(false)
  }

  return (
    <Dialog open={open} onOpenChange={handleOpen}>
      <DialogContent className="max-w-sm">
        <DialogHeader>
          <DialogTitle>Editar Jugador</DialogTitle>
        </DialogHeader>
        <div className="space-y-3 mt-2">
          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="text-xs text-muted-foreground mb-1 block">Nombre</label>
              <Input value={name} onChange={e => setName(e.target.value)} />
            </div>
            <div>
              <label className="text-xs text-muted-foreground mb-1 block">Apodo</label>
              <Input value={nickname} onChange={e => setNickname(e.target.value)} placeholder="Opcional" />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="text-xs text-muted-foreground mb-1 block">Dorsal</label>
              <Input type="number" min="1" max="99" value={number} onChange={e => setNumber(e.target.value)} />
            </div>
            <div>
              <label className="text-xs text-muted-foreground mb-1 block">Posición</label>
              <select value={position} onChange={e => setPosition(e.target.value)}
                className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm text-foreground h-10">
                <option value="">—</option>
                {POSITIONS.map(p => <option key={p} value={p}>{p}</option>)}
              </select>
            </div>
          </div>
          <div>
            <label className="text-xs text-muted-foreground mb-1 block">Fecha de nacimiento</label>
            <Input type="date" value={birthDate} onChange={e => setBirthDate(e.target.value)} />
          </div>
          <div>
            <label className="text-xs text-muted-foreground mb-1 block">URL foto del jugador</label>
            <Input value={photoUrl} onChange={e => setPhotoUrl(e.target.value)} placeholder="https://..." />
            {photoUrl && (
              <img src={photoUrl} className="mt-2 w-12 h-12 rounded-full object-cover border border-border" alt="preview" />
            )}
          </div>
          <div className="flex gap-2 justify-end pt-2">
            <Button variant="outline" size="sm" onClick={onClose}>Cancelar</Button>
            <Button size="sm" onClick={handleSave} disabled={saving}>
              <Check className="w-4 h-4 mr-1" />{saving ? 'Guardando...' : 'Guardar'}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
