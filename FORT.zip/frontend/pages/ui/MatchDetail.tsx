import { useEffect, useState } from 'react'
import { X, Plus, Trash2, ArrowLeftRight } from 'lucide-react'
import {
  useGetMatchDetail, useAddMatchEvent, useRemoveMatchEvent,
  useUpdateMatch, useAddSubstitution, useRemoveSubstitution, useSetMatchLineup
} from '../../hooks/backend/matches'
import { useGetPlayers } from '../../hooks/backend/players'
import { Input } from '../../lib/shadcn/input'
import { cn } from '../../lib/shadcn/utils'

type Tab = 'marcador' | 'eventos' | 'alineacion' | 'cambios'

const EVENT_TYPES = [
  { value: 'goal', label: '⚽ Gol' },
  { value: 'assist', label: '🎯 Asistencia' },
  { value: 'yellow_card', label: '🟡 Tarjeta Amarilla' },
  { value: 'red_card', label: '🔴 Tarjeta Roja' },
]

const EVENT_ICONS: Record<string, string> = {
  goal: '⚽', assist: '🎯', yellow_card: '🟡', red_card: '🔴',
}

interface PlayerRec { id: number; name: string; nickname: string | null; number: number | null; team_id: number }
interface LineupRec { player_id: number; type: string; player_name: string; number: number | null; team_id: number }
interface EventRec { id: number; player_id: number; event_type: string; minute: number | null; player_name: string; nickname: string | null; number: number | null; team_id: number; team_color: string; team_name: string | null }
interface SubRec { id: number; player_out_id: number; player_in_id: number; minute: number | null; player_out_name: string; player_in_name: string; player_out_number: number | null; player_in_number: number | null; team_id: number }

function PlayerBadge({ p, lineupType, onToggle }: {
  p: PlayerRec; lineupType: string | null; onToggle: (type: 'starter' | 'substitute' | 'remove') => void
}) {
  return (
    <button
      onClick={() => {
        if (!lineupType) onToggle('starter')
        else if (lineupType === 'starter') onToggle('substitute')
        else onToggle('remove')
      }}
      className={cn(
        'flex items-center gap-2 w-full px-2 py-1.5 rounded-lg text-xs font-medium transition-all',
        lineupType === 'starter'
          ? 'bg-blue-600/30 border border-blue-500/50 text-blue-200'
          : lineupType === 'substitute'
          ? 'bg-yellow-600/20 border border-yellow-500/40 text-yellow-200'
          : 'border border-white/5 text-white/40 hover:text-white/70 hover:border-white/20'
      )}
      style={{ background: lineupType === 'starter' ? 'rgba(37,99,235,0.25)' : lineupType === 'substitute' ? 'rgba(217,119,6,0.2)' : 'rgba(255,255,255,0.03)' }}
    >
      <span className="w-5 text-center font-mono" style={{ color: lineupType ? 'inherit' : '#38bdf8' }}>
        {p.number ?? '—'}
      </span>
      <span className="flex-1 text-left truncate">{p.name}</span>
      {lineupType === 'starter' && <span className="text-[10px] font-bold text-blue-300">T</span>}
      {lineupType === 'substitute' && <span className="text-[10px] font-bold text-yellow-300">R</span>}
    </button>
  )
}

export function MatchDetail({ matchId, teamColor, canEdit, onClose }: {
  matchId: number; teamColor: string; canEdit: boolean; onClose: () => void
}) {
  const { data: detailData, trigger: triggerDetail } = useGetMatchDetail()
  const { trigger: addEvent } = useAddMatchEvent()
  const { trigger: removeEvent } = useRemoveMatchEvent()
  const { trigger: updateMatch } = useUpdateMatch()
  const { trigger: addSub } = useAddSubstitution()
  const { trigger: removeSub } = useRemoveSubstitution()
  const { trigger: setLineup } = useSetMatchLineup()
  const { data: homePlayersData, trigger: triggerHomePlayers } = useGetPlayers()
  const { data: awayPlayersData, trigger: triggerAwayPlayers } = useGetPlayers()

  const [tab, setTab] = useState<Tab>('marcador')
  const [homeScore, setHomeScore] = useState('')
  const [awayScore, setAwayScore] = useState('')
  const [status, setStatus] = useState('')
  const [eventType, setEventType] = useState('goal')
  const [eventPlayer, setEventPlayer] = useState('')
  const [eventMinute, setEventMinute] = useState('')
  const [subOut, setSubOut] = useState('')
  const [subIn, setSubIn] = useState('')
  const [subMinute, setSubMinute] = useState('')

  const detail = detailData as { match: Record<string,unknown>; events: EventRec[]; lineup: LineupRec[]; substitutions: SubRec[] } | undefined
  const match = detail?.match as { home_team_id: number; away_team_id: number; home_score: number; away_score: number; status: string; home_team_name: string; away_team_name: string; home_color: string; away_color: string } | undefined

  useEffect(() => {
    triggerDetail({ match_id: matchId })
  }, [matchId])

  useEffect(() => {
    if (match) {
      setHomeScore(match.home_score?.toString() ?? '0')
      setAwayScore(match.away_score?.toString() ?? '0')
      setStatus(match.status ?? 'scheduled')
      triggerHomePlayers({ team_id: match.home_team_id })
      triggerAwayPlayers({ team_id: match.away_team_id })
    }
  }, [match?.home_team_id])

  const reload = () => triggerDetail({ match_id: matchId })

  const homePlayers = (homePlayersData as PlayerRec[] | undefined) ?? []
  const awayPlayers = (awayPlayersData as PlayerRec[] | undefined) ?? []
  const allPlayers = [...homePlayers, ...awayPlayers]
  const events = detail?.events ?? []
  const lineup = detail?.lineup ?? []
  const subs = detail?.substitutions ?? []

  function getLineupType(playerId: number) {
    return lineup.find(l => l.player_id === playerId)?.type ?? null
  }

  async function handleSaveScore() {
    await updateMatch({ match_id: matchId, home_score: parseInt(homeScore), away_score: parseInt(awayScore), status })
    reload()
  }

  async function handleAddEvent() {
    if (!eventPlayer) return
    await addEvent({ match_id: matchId, player_id: parseInt(eventPlayer), event_type: eventType as 'goal', minute: eventMinute ? parseInt(eventMinute) : undefined })
    setEventPlayer(''); setEventMinute('')
    reload()
  }

  async function handleAddSub() {
    if (!subOut || !subIn) return
    await addSub({ match_id: matchId, player_out_id: parseInt(subOut), player_in_id: parseInt(subIn), minute: subMinute ? parseInt(subMinute) : undefined })
    setSubOut(''); setSubIn(''); setSubMinute('')
    reload()
  }

  const TAB_LABELS: { key: Tab; label: string }[] = [
    { key: 'marcador', label: '🏟️ Marcador' },
    { key: 'eventos', label: '⚽ Eventos' },
    { key: 'alineacion', label: '👥 Alineación' },
    { key: 'cambios', label: '🔄 Cambios' },
  ]

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3" style={{ background: 'rgba(0,0,0,0.9)' }} onClick={onClose}>
      <div className="relative w-full max-w-2xl max-h-[92vh] flex flex-col rounded-2xl overflow-hidden"
        style={{ background: '#0a0f1e', border: '1px solid #1e3a5f' }}
        onClick={e => e.stopPropagation()}>

        {/* Header */}
        <div className="h-1 flex-shrink-0" style={{ background: `linear-gradient(90deg, ${match?.home_color ?? teamColor}, ${match?.away_color ?? '#38bdf8'})` }} />
        <div className="flex items-center justify-between px-5 py-3 border-b flex-shrink-0" style={{ borderColor: '#1e3a5f' }}>
          <div className="flex items-center gap-4">
            <span className="font-black uppercase text-white text-sm">{match?.home_team_name ?? '...'}</span>
            <div className="flex items-center gap-2 px-4 py-1 rounded-lg" style={{ background: '#111e35', border: '1px solid #1e3a5f' }}>
              <span className="font-black text-xl text-white">{homeScore}</span>
              <span className="text-white/40">:</span>
              <span className="font-black text-xl text-white">{awayScore}</span>
            </div>
            <span className="font-black uppercase text-white text-sm">{match?.away_team_name ?? '...'}</span>
          </div>
          <button onClick={onClose} className="rounded-full p-1.5" style={{ background: 'rgba(255,255,255,0.05)' }}>
            <X className="w-4 h-4 text-white" />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex border-b flex-shrink-0" style={{ borderColor: '#1e3a5f' }}>
          {TAB_LABELS.map(t => (
            <button key={t.key} onClick={() => setTab(t.key)}
              className={cn('flex-1 py-2.5 text-xs font-semibold transition-colors',
                tab === t.key ? 'text-white border-b-2' : 'text-white/40 hover:text-white/70'
              )}
              style={tab === t.key ? { borderColor: '#38bdf8', color: '#38bdf8' } : {}}>
              {t.label}
            </button>
          ))}
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-4">

          {/* MARCADOR */}
          {tab === 'marcador' && (
            <div className="space-y-4">
              <div className="flex items-center gap-4 justify-center">
                <div className="text-center">
                  <p className="text-xs text-white/40 mb-1 uppercase">{match?.home_team_name}</p>
                  <Input type="number" min="0" value={homeScore} onChange={e => setHomeScore(e.target.value)}
                    className="w-20 text-center text-2xl font-black bg-transparent border-white/20 text-white" disabled={!canEdit} />
                </div>
                <span className="text-white/30 text-2xl font-bold mt-4">:</span>
                <div className="text-center">
                  <p className="text-xs text-white/40 mb-1 uppercase">{match?.away_team_name}</p>
                  <Input type="number" min="0" value={awayScore} onChange={e => setAwayScore(e.target.value)}
                    className="w-20 text-center text-2xl font-black bg-transparent border-white/20 text-white" disabled={!canEdit} />
                </div>
              </div>
              {canEdit && (
                <div className="flex gap-2 items-center justify-center">
                  <select value={status} onChange={e => setStatus(e.target.value)}
                    className="rounded-lg px-3 py-2 text-sm font-medium text-white" style={{ background: '#111e35', border: '1px solid #1e3a5f' }}>
                    <option value="scheduled">Programado</option>
                    <option value="live">En vivo</option>
                    <option value="finished">Finalizado</option>
                    <option value="cancelled">Cancelado</option>
                  </select>
                  <button onClick={handleSaveScore} className="px-4 py-2 rounded-lg text-sm font-bold" style={{ background: '#38bdf8', color: '#0a0f1e' }}>
                    Guardar
                  </button>
                </div>
              )}
            </div>
          )}

          {/* EVENTOS */}
          {tab === 'eventos' && (
            <div className="space-y-4">
              {canEdit && (
                <div className="rounded-xl p-3 space-y-2" style={{ background: '#111e35', border: '1px solid #1e3a5f' }}>
                  <p className="text-xs font-semibold uppercase tracking-wider mb-2" style={{ color: '#38bdf8' }}>Añadir evento</p>
                  <div className="flex gap-2 flex-wrap">
                    <select value={eventType} onChange={e => setEventType(e.target.value)} className="rounded-lg px-2 py-1.5 text-sm text-white flex-1 min-w-[140px]" style={{ background: '#0d1424', border: '1px solid #1e3a5f' }}>
                      {EVENT_TYPES.map(t => <option key={t.value} value={t.value}>{t.label}</option>)}
                    </select>
                    <select value={eventPlayer} onChange={e => setEventPlayer(e.target.value)} className="rounded-lg px-2 py-1.5 text-sm text-white flex-1 min-w-[140px]" style={{ background: '#0d1424', border: '1px solid #1e3a5f' }}>
                      <option value="">Jugador...</option>
                      {allPlayers.map(p => <option key={p.id} value={p.id}>{p.number ? `#${p.number} ` : ''}{p.name}</option>)}
                    </select>
                    <Input type="number" placeholder="Min." value={eventMinute} onChange={e => setEventMinute(e.target.value)}
                      className="w-16 text-white bg-transparent" style={{ borderColor: '#1e3a5f' }} />
                    <button onClick={handleAddEvent} className="px-3 py-1.5 rounded-lg text-sm font-bold" style={{ background: '#38bdf8', color: '#0a0f1e' }}>
                      <Plus className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              )}
              <div className="space-y-1.5">
                {events.length === 0 && <p className="text-center text-white/30 py-6 text-sm">Sin eventos registrados</p>}
                {events.map(ev => (
                  <div key={ev.id} className="flex items-center gap-3 px-3 py-2 rounded-lg" style={{ background: '#111e35', border: '1px solid #1e3a5f' }}>
                    <span className="text-base">{EVENT_ICONS[ev.event_type] ?? '•'}</span>
                    <div className="flex-1">
                      <span className="text-sm font-bold text-white">{ev.nickname ?? ev.player_name}</span>
                      <span className="text-xs text-white/40 ml-2">{ev.team_name ?? ''}</span>
                    </div>
                    {ev.minute && <span className="text-xs font-mono" style={{ color: '#38bdf8' }}>{ev.minute}'</span>}
                    {canEdit && (
                      <button onClick={async () => { await removeEvent({ event_id: ev.id }); reload() }} className="text-red-400 hover:text-red-300">
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* ALINEACION */}
          {tab === 'alineacion' && (
            <div className="grid grid-cols-2 gap-4">
              {[{ label: match?.home_team_name ?? 'Local', players: homePlayers, color: match?.home_color ?? teamColor },
                { label: match?.away_team_name ?? 'Visitante', players: awayPlayers, color: match?.away_color ?? '#38bdf8' }
              ].map(team => (
                <div key={team.label}>
                  <div className="flex items-center gap-2 mb-2 pb-2" style={{ borderBottom: `1px solid ${team.color}40` }}>
                    <div className="w-2 h-2 rounded-full" style={{ background: team.color }} />
                    <p className="text-xs font-bold uppercase text-white truncate">{team.label}</p>
                  </div>
                  <p className="text-[10px] text-white/40 mb-1 uppercase tracking-wider">Titulares <span style={{ color: '#38bdf8' }}>T</span> · Reservas <span style={{ color: '#f59e0b' }}>R</span> · Clic para cambiar</p>
                  <div className="space-y-1">
                    {team.players.map(p => (
                      <PlayerBadge key={p.id} p={p} lineupType={getLineupType(p.id)}
                        onToggle={canEdit ? async (type) => { await setLineup({ match_id: matchId, player_id: p.id, type }); reload() } : () => {}} />
                    ))}
                    {team.players.length === 0 && <p className="text-xs text-white/20 text-center py-4">Sin jugadores</p>}
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* CAMBIOS */}
          {tab === 'cambios' && (
            <div className="space-y-4">
              {canEdit && (
                <div className="rounded-xl p-3 space-y-2" style={{ background: '#111e35', border: '1px solid #1e3a5f' }}>
                  <p className="text-xs font-semibold uppercase tracking-wider mb-2" style={{ color: '#38bdf8' }}>Añadir cambio</p>
                  <div className="flex gap-2 flex-wrap items-center">
                    <select value={subOut} onChange={e => setSubOut(e.target.value)} className="rounded-lg px-2 py-1.5 text-sm text-white flex-1 min-w-[120px]" style={{ background: '#0d1424', border: '1px solid #1e3a5f' }}>
                      <option value="">Sale...</option>
                      {allPlayers.map(p => <option key={p.id} value={p.id}>{p.number ? `#${p.number} ` : ''}{p.name}</option>)}
                    </select>
                    <ArrowLeftRight className="w-4 h-4 flex-shrink-0" style={{ color: '#38bdf8' }} />
                    <select value={subIn} onChange={e => setSubIn(e.target.value)} className="rounded-lg px-2 py-1.5 text-sm text-white flex-1 min-w-[120px]" style={{ background: '#0d1424', border: '1px solid #1e3a5f' }}>
                      <option value="">Entra...</option>
                      {allPlayers.map(p => <option key={p.id} value={p.id}>{p.number ? `#${p.number} ` : ''}{p.name}</option>)}
                    </select>
                    <Input type="number" placeholder="Min." value={subMinute} onChange={e => setSubMinute(e.target.value)}
                      className="w-16 text-white bg-transparent" style={{ borderColor: '#1e3a5f' }} />
                    <button onClick={handleAddSub} className="px-3 py-1.5 rounded-lg text-sm font-bold" style={{ background: '#38bdf8', color: '#0a0f1e' }}>
                      <Plus className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              )}
              <div className="space-y-1.5">
                {subs.length === 0 && <p className="text-center text-white/30 py-6 text-sm">Sin cambios registrados</p>}
                {subs.map(s => (
                  <div key={s.id} className="flex items-center gap-3 px-3 py-2 rounded-lg" style={{ background: '#111e35', border: '1px solid #1e3a5f' }}>
                    <span className="text-red-400 text-xs font-bold">▼</span>
                    <span className="text-sm text-white/70">{s.player_out_name}</span>
                    <ArrowLeftRight className="w-3.5 h-3.5 flex-shrink-0" style={{ color: '#38bdf8' }} />
                    <span className="text-green-400 text-xs font-bold">▲</span>
                    <span className="text-sm text-white flex-1">{s.player_in_name}</span>
                    {s.minute && <span className="text-xs font-mono" style={{ color: '#38bdf8' }}>{s.minute}'</span>}
                    {canEdit && (
                      <button onClick={async () => { await removeSub({ substitution_id: s.id }); reload() }} className="text-red-400 hover:text-red-300">
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
