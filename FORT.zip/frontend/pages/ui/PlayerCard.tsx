import { Edit2 } from 'lucide-react'

export interface PlayerWithStats {
  id: number
  name: string
  nickname: string | null
  photo_url: string | null
  number: number | null
  position: string | null
  birth_date: string | null
  user_email: string | null
  goals: number
  assists: number
  yellow_cards: number
  red_cards: number
}

function formatBirthDate(dateStr: string | null) {
  if (!dateStr) return null
  const d = new Date(dateStr)
  return d.toLocaleDateString('es-ES', { day: '2-digit', month: '2-digit', year: 'numeric' })
}

export function PlayerCard({
  player,
  canEdit,
  onClick,
  onEdit,
}: {
  player: PlayerWithStats
  canEdit: boolean
  onClick: () => void
  onEdit: (e: React.MouseEvent) => void
}) {
  return (
    <div
      onClick={onClick}
      className="relative flex items-center gap-3 rounded-lg cursor-pointer group transition-all duration-200 hover:scale-[1.01] p-3"
      style={{ background: 'linear-gradient(135deg, #131e3a 0%, #1a2540 100%)', border: '1px solid #1e3a5f' }}
    >
      {/* Player avatar + number badge */}
      <div className="relative flex-shrink-0">
        <div className="w-12 h-12 rounded-full overflow-hidden border-2 border-[#1e3a5f] bg-[#0d1829]">
          {player.photo_url ? (
            <img src={player.photo_url} className="w-full h-full object-cover" alt={player.name} />
          ) : (
            <div className="w-full h-full flex items-center justify-center text-[#4a90b8] text-base font-bold">
              {player.name.slice(0, 1).toUpperCase()}
            </div>
          )}
        </div>
        {player.number !== null && (
          <div className="absolute -bottom-1 -right-1 w-5 h-5 rounded-full bg-[#0a0f1e] border border-[#1e3a5f] flex items-center justify-center">
            <span className="text-[9px] font-bold text-[#4a90b8]">#{player.number}</span>
          </div>
        )}
      </div>

      {/* Info */}
      <div className="flex-1 min-w-0">
        <p className="font-extrabold text-white uppercase text-xs leading-tight tracking-wide truncate"
          style={{ textShadow: '0 0 10px rgba(56,189,248,0.2)' }}>
          {player.name}
        </p>
        {player.position && (
          <p className="text-[10px] font-semibold uppercase tracking-wider mt-0.5"
            style={{ color: '#38bdf8' }}>
            {player.position}
          </p>
        )}
        {player.birth_date && (
          <p className="text-[10px] mt-0.5" style={{ color: '#4a6080' }}>
            Nac: {formatBirthDate(player.birth_date)}
          </p>
        )}
      </div>

      {/* Jersey number large */}
      {player.number !== null && (
        <div className="flex-shrink-0 w-10 text-right">
          <span
            className="font-black leading-none select-none"
            style={{
              fontSize: '2.2rem',
              color: 'transparent',
              WebkitTextStroke: '2px #38bdf8',
              textShadow: '0 0 20px rgba(56,189,248,0.3)',
            }}
          >
            {player.number}
          </span>
        </div>
      )}

      {/* Edit button */}
      {canEdit && (
        <button
          onClick={onEdit}
          className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity p-1 rounded"
          style={{ background: 'rgba(56,189,248,0.15)' }}
        >
          <Edit2 className="w-3 h-3" style={{ color: '#38bdf8' }} />
        </button>
      )}
    </div>
  )
}
