import { useEffect, useState } from 'react'
import { Settings, Search, ChevronDown, Check, AlertCircle } from 'lucide-react'
import { useGetUsers, useUpdateUserRole } from '../hooks/backend/admin'
import { useGetPlayers } from '../hooks/backend/players'
import { useUpdatePlayer } from '../hooks/backend/players'
import { useGetTeams } from '../hooks/backend/teams'
import { useAppContext } from '../context/AppContext'
import type { Team } from '../types'
import { cn } from '../lib/shadcn/utils'
import { Input } from '../lib/shadcn/input'
import { Button } from '../lib/shadcn/button'
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '../lib/shadcn/dialog'

interface AdminUser {
  id: number
  email: string
  username: string
  role: string
  avatar_url: string | null
  created_at: string
  player_id: number | null
  player_name: string | null
  team_id: number | null
  team_name: string | null
}

interface PlayerRecord {
  id: number
  name: string
  nickname: string | null
  team_id: number
  user_id: number | null
  number: number | null
  position: string | null
}

const ROLES = [
  { value: 'player', label: 'Jugador', color: 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200' },
  { value: 'captain', label: 'Capitán', color: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200' },
  { value: 'referee', label: 'Árbitro', color: 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200' },
  { value: 'administrator', label: 'Administrador', color: 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200' },
]

export default function Admin() {
  const { appUser } = useAppContext()
  const { data: usersData, loading, trigger: triggerUsers } = useGetUsers()
  const { trigger: updateRole } = useUpdateUserRole()
  const { data: playersData, trigger: triggerPlayers } = useGetPlayers()
  const { trigger: linkPlayer } = useUpdatePlayer()
  const { data: teamsData, trigger: triggerTeams } = useGetTeams()

  const [search, setSearch] = useState('')
  const [roleFilter, setRoleFilter] = useState('todos')
  const [linkingUser, setLinkingUser] = useState<AdminUser | null>(null)
  const [selectedTeamId, setSelectedTeamId] = useState('')
  const [selectedPlayerId, setSelectedPlayerId] = useState('')
  const [changingRole, setChangingRole] = useState<number | null>(null)

  useEffect(() => {
    if (appUser?.role === 'administrator') {
      triggerUsers()
      triggerTeams({})
    }
  }, [appUser?.role])

  useEffect(() => {
    if (selectedTeamId) {
      triggerPlayers({ team_id: parseInt(selectedTeamId) })
    }
  }, [selectedTeamId])

  const users = (usersData as AdminUser[] | undefined) ?? []
  const players = (playersData as PlayerRecord[] | undefined) ?? []
  const teams = (teamsData as Team[] | undefined) ?? []

  const filtered = users.filter(u => {
    const matchSearch = !search || u.email.toLowerCase().includes(search.toLowerCase())
      || u.username.toLowerCase().includes(search.toLowerCase())
    const matchRole = roleFilter === 'todos' || u.role === roleFilter
    return matchSearch && matchRole
  })

  async function handleUpdateRole(userId: number, newRole: string) {
    setChangingRole(userId)
    await updateRole({ user_id: userId, role: newRole })
    setChangingRole(null)
    triggerUsers()
  }

  async function handleLinkPlayer() {
    if (!linkingUser || !selectedPlayerId) return
    await linkPlayer({
      player_id: parseInt(selectedPlayerId),
      user_id: linkingUser.id,
    })
    setLinkingUser(null)
    setSelectedTeamId('')
    setSelectedPlayerId('')
    triggerUsers()
  }

  if (appUser?.role !== 'administrator') {
    return (
      <div className="p-6 max-w-xl mx-auto">
        <div className="bg-card border border-border rounded-xl p-8 text-center">
          <AlertCircle className="w-12 h-12 text-muted-foreground mx-auto mb-3" />
          <h2 className="text-lg font-semibold text-foreground mb-2">Acceso restringido</h2>
          <p className="text-muted-foreground text-sm">Solo los administradores pueden acceder a este panel.</p>
        </div>
      </div>
    )
  }

  return (
    <div className="p-6 max-w-5xl mx-auto">
      <div className="flex items-center gap-3 mb-6">
        <Settings className="w-6 h-6 text-primary" />
        <div>
          <h1 className="text-2xl font-bold text-foreground">Panel de Administración</h1>
          <p className="text-sm text-muted-foreground">Gestión de usuarios y roles</p>
        </div>
      </div>

      {/* Stats row */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-6">
        {ROLES.map(r => {
          const count = users.filter(u => u.role === r.value).length
          return (
            <div key={r.value} className="bg-card border border-border rounded-xl p-3">
              <span className={cn('text-xs px-2 py-0.5 rounded-full font-medium', r.color)}>{r.label}</span>
              <p className="text-2xl font-bold text-foreground mt-1">{count}</p>
            </div>
          )
        })}
      </div>

      {/* Filters */}
      <div className="flex gap-3 mb-4 flex-wrap">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <Input placeholder="Buscar por nombre o email..." value={search} onChange={e => setSearch(e.target.value)} className="pl-9" />
        </div>
        <div className="flex gap-1 bg-muted rounded-lg p-1">
          {[{ value: 'todos', label: 'Todos' }, ...ROLES].map(r => (
            <button
              key={r.value}
              onClick={() => setRoleFilter(r.value)}
              className={cn('px-3 py-1 rounded text-xs font-medium transition-colors',
                roleFilter === r.value
                  ? 'bg-background text-foreground shadow-sm'
                  : 'text-muted-foreground hover:text-foreground'
              )}
            >
              {r.label}
            </button>
          ))}
        </div>
      </div>

      {/* Users table */}
      <div className="bg-card border border-border rounded-xl overflow-hidden">
        {loading ? (
          <div className="p-8 text-center text-muted-foreground">Cargando usuarios...</div>
        ) : filtered.length === 0 ? (
          <div className="p-8 text-center text-muted-foreground">No se encontraron usuarios</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-muted/40 border-b border-border">
                  <th className="px-4 py-3 text-left text-xs font-semibold text-muted-foreground uppercase">Usuario</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-muted-foreground uppercase hidden sm:table-cell">Email</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-muted-foreground uppercase">Rol</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-muted-foreground uppercase hidden md:table-cell">Jugador</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-muted-foreground uppercase">Acciones</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map(u => (
                  <tr key={u.id} className="border-b border-border/50 hover:bg-muted/20">
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center text-xs font-bold text-primary">
                          {u.username.slice(0, 2).toUpperCase()}
                        </div>
                        <span className="font-medium text-foreground">{u.username}</span>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-muted-foreground hidden sm:table-cell">{u.email}</td>
                    <td className="px-4 py-3">
                      {changingRole === u.id ? (
                        <span className="text-muted-foreground text-xs">Guardando...</span>
                      ) : (
                        <div className="relative inline-block">
                          <select
                            value={u.role}
                            onChange={e => handleUpdateRole(u.id, e.target.value)}
                            disabled={u.id === appUser?.id}
                            className="appearance-none bg-transparent border border-input rounded px-2 py-1 pr-6 text-xs font-medium cursor-pointer disabled:opacity-50 disabled:cursor-default text-foreground"
                          >
                            {ROLES.map(r => (
                              <option key={r.value} value={r.value}>{r.label}</option>
                            ))}
                          </select>
                          <ChevronDown className="w-3 h-3 absolute right-1.5 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none" />
                        </div>
                      )}
                    </td>
                    <td className="px-4 py-3 hidden md:table-cell">
                      {u.player_name ? (
                        <div>
                          <span className="text-foreground text-xs font-medium">{u.player_name}</span>
                          {u.team_name && <span className="text-muted-foreground text-xs ml-1">· {u.team_name}</span>}
                        </div>
                      ) : (
                        <span className="text-muted-foreground text-xs">Sin jugador</span>
                      )}
                    </td>
                    <td className="px-4 py-3">
                      <button
                        onClick={() => { setLinkingUser(u); setSelectedTeamId(''); setSelectedPlayerId('') }}
                        className="text-xs text-primary hover:underline"
                      >
                        {u.player_id ? 'Cambiar jugador' : 'Vincular jugador'}
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Link player dialog */}
      <Dialog open={!!linkingUser} onOpenChange={(open) => { if (!open) setLinkingUser(null) }}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>Vincular Jugador</DialogTitle>
          </DialogHeader>
          {linkingUser && (
            <div className="space-y-3 mt-2">
              <p className="text-sm text-muted-foreground">
                Vinculando jugador a: <span className="font-medium text-foreground">{linkingUser.username}</span>
              </p>
              <div>
                <label className="text-xs text-muted-foreground mb-1 block">1. Selecciona el equipo</label>
                <select value={selectedTeamId} onChange={e => { setSelectedTeamId(e.target.value); setSelectedPlayerId('') }}
                  className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm text-foreground">
                  <option value="">Seleccionar equipo...</option>
                  {teams.map(t => <option key={t.id} value={t.id}>{t.name}</option>)}
                </select>
              </div>
              {selectedTeamId && (
                <div>
                  <label className="text-xs text-muted-foreground mb-1 block">2. Selecciona el jugador</label>
                  <select value={selectedPlayerId} onChange={e => setSelectedPlayerId(e.target.value)}
                    className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm text-foreground">
                    <option value="">Seleccionar jugador...</option>
                    {players.map(p => (
                      <option key={p.id} value={p.id}>
                        {p.number ? `#${p.number} ` : ''}{p.name}{p.user_id ? ' (vinculado)' : ''}
                      </option>
                    ))}
                  </select>
                </div>
              )}
              <div className="flex gap-2 justify-end pt-2">
                <Button variant="outline" size="sm" onClick={() => setLinkingUser(null)}>Cancelar</Button>
                <Button size="sm" disabled={!selectedPlayerId} onClick={handleLinkPlayer}>
                  <Check className="w-4 h-4 mr-1" /> Vincular
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}
