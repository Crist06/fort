import { useEffect, useState } from 'react'
import { BarChart3 } from 'lucide-react'
import { useGetTopStats } from '../hooks/backend/stats'
import { useAppContext } from '../context/AppContext'
import type { PlayerStat } from '../types'
import { cn } from '../lib/shadcn/utils'

type StatTab = 'goals' | 'assists' | 'yellow_cards' | 'red_cards'

const TABS: { key: StatTab; label: string; emoji: string }[] = [
  { key: 'goals', label: 'Goleadores', emoji: '⚽' },
  { key: 'assists', label: 'Asistidores', emoji: '🎯' },
  { key: 'yellow_cards', label: 'Tarjetas Amarillas', emoji: '🟡' },
  { key: 'red_cards', label: 'Tarjetas Rojas', emoji: '🔴' },
]

function PlayerRow({ stat, rank, valueKey }: { stat: PlayerStat; rank: number; valueKey: StatTab }) {
  const value = stat[valueKey]
  const displayName = stat.nickname ? `${stat.nickname}` : stat.name

  return (
    <div className={cn(
      'flex items-center gap-4 px-4 py-3 border-b border-border/50 hover:bg-muted/20 transition-colors',
      rank === 1 && 'bg-yellow-50/30 dark:bg-yellow-950/20'
    )}>
      <div className="w-7 flex-shrink-0 text-center">
        {rank === 1 ? (
          <span className="text-lg">🥇</span>
        ) : rank === 2 ? (
          <span className="text-lg">🥈</span>
        ) : rank === 3 ? (
          <span className="text-lg">🥉</span>
        ) : (
          <span className="text-sm text-muted-foreground font-medium">{rank}</span>
        )}
      </div>
      <div className="flex-shrink-0">
        {stat.photo_url ? (
          <img src={stat.photo_url} className="w-9 h-9 rounded-full object-cover" alt={stat.name} />
        ) : (
          <div className="w-9 h-9 rounded-full flex items-center justify-center text-white text-sm font-bold"
            style={{ backgroundColor: stat.team_color }}>
            {stat.name.slice(0, 1)}
          </div>
        )}
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2">
          <span className="font-semibold text-foreground text-sm truncate">{displayName}</span>
          {stat.nickname && stat.name !== displayName && (
            <span className="text-xs text-muted-foreground truncate hidden sm:block">{stat.name}</span>
          )}
        </div>
        <div className="flex items-center gap-2 mt-0.5">
          <span className="inline-block w-2.5 h-2.5 rounded-full flex-shrink-0"
            style={{ backgroundColor: stat.team_color }} />
          <span className="text-xs text-muted-foreground truncate">{stat.team_name}</span>
          {stat.position && (
            <span className="text-xs text-muted-foreground hidden sm:block">· {stat.position}</span>
          )}
        </div>
      </div>
      <div className="flex-shrink-0 text-right">
        <span className="text-2xl font-bold text-foreground">{value}</span>
        <p className="text-xs text-muted-foreground">
          {valueKey === 'goals' ? 'goles'
            : valueKey === 'assists' ? 'asist.'
            : valueKey === 'yellow_cards' ? 'amarillas'
            : 'rojas'}
        </p>
      </div>
    </div>
  )
}

export default function Estadisticas() {
  const { activeSeason } = useAppContext()
  const { data: statsData, loading, trigger: triggerStats } = useGetTopStats()
  const [activeTab, setActiveTab] = useState<StatTab>('goals')

  useEffect(() => {
    if (activeSeason) {
      triggerStats({ season_id: activeSeason.id })
    }
  }, [activeSeason?.id])

  const allStats = (statsData as PlayerStat[] | undefined) ?? []

  const sorted = [...allStats]
    .filter(s => s[activeTab] > 0)
    .sort((a, b) => b[activeTab] - a[activeTab])

  return (
    <div className="p-6 max-w-3xl mx-auto">
      <div className="flex items-center gap-3 mb-6">
        <BarChart3 className="w-6 h-6 text-primary" />
        <div>
          <h1 className="text-2xl font-bold text-foreground">Estadísticas</h1>
          {activeSeason && <p className="text-sm text-muted-foreground">{activeSeason.name}</p>}
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 bg-muted rounded-xl p-1 mb-6 flex-wrap">
        {TABS.map(tab => (
          <button
            key={tab.key}
            onClick={() => setActiveTab(tab.key)}
            className={cn(
              'flex-1 flex items-center justify-center gap-1.5 px-3 py-2 rounded-lg text-sm font-medium transition-colors min-w-[100px]',
              activeTab === tab.key
                ? 'bg-background text-foreground shadow-sm'
                : 'text-muted-foreground hover:text-foreground'
            )}
          >
            <span>{tab.emoji}</span>
            <span className="hidden sm:block">{tab.label}</span>
          </button>
        ))}
      </div>

      <div className="bg-card border border-border rounded-xl overflow-hidden">
        {loading ? (
          <div className="p-8 text-center text-muted-foreground">Cargando estadísticas...</div>
        ) : sorted.length === 0 ? (
          <div className="p-8 text-center text-muted-foreground">
            No hay estadísticas para mostrar todavía
          </div>
        ) : (
          <div>
            {sorted.map((stat, i) => (
              <PlayerRow key={stat.id} stat={stat} rank={i + 1} valueKey={activeTab} />
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
