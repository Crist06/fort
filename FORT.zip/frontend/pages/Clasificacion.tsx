import { useEffect, useState } from 'react'
import { Trophy, Minus, TrendingUp, TrendingDown, Settings, Plus, Trash2, Check } from 'lucide-react'
import { useGetStandings } from '../hooks/backend/stats'
import { useGetGroups, useGetStandingRules, useSaveStandingRules } from '../hooks/backend/seasons'
import { useAppContext } from '../context/AppContext'
import type { Standing, Group } from '../types'
import { cn } from '../lib/shadcn/utils'
import { Button } from '../lib/shadcn/button'
import { Input } from '../lib/shadcn/input'
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '../lib/shadcn/dialog'

interface StandingRule {
  id?: number
  position_from: number
  position_to: number
  color: string
  label: string
}

const PRESET_RULES: StandingRule[] = [
  { position_from: 1, position_to: 1, color: '#f59e0b', label: 'Campeón' },
  { position_from: 2, position_to: 2, color: '#22c55e', label: 'Ascenso' },
  { position_from: 3, position_to: 4, color: '#3b82f6', label: 'Play-off' },
]

function getPositionColor(position: number, rules: StandingRule[]): string | null {
  const rule = rules.find(r => position >= r.position_from && position <= r.position_to)
  return rule?.color ?? null
}

function RuleRow({ rule, onChange, onDelete }: {
  rule: StandingRule
  onChange: (r: StandingRule) => void
  onDelete: () => void
}) {
  return (
    <div className="flex items-center gap-2 py-2 border-b border-border/50">
      <input type="color" value={rule.color} onChange={e => onChange({ ...rule, color: e.target.value })}
        className="w-8 h-8 rounded cursor-pointer border border-border flex-shrink-0" />
      <Input value={rule.label} onChange={e => onChange({ ...rule, label: e.target.value })}
        placeholder="Etiqueta" className="flex-1 h-8 text-sm" />
      <div className="flex items-center gap-1 flex-shrink-0">
        <span className="text-xs text-muted-foreground">Puestos</span>
        <Input type="number" min="1" value={rule.position_from} onChange={e => onChange({ ...rule, position_from: parseInt(e.target.value) || 1 })}
          className="w-12 h-8 text-xs text-center" />
        <span className="text-xs text-muted-foreground">—</span>
        <Input type="number" min="1" value={rule.position_to} onChange={e => onChange({ ...rule, position_to: parseInt(e.target.value) || 1 })}
          className="w-12 h-8 text-xs text-center" />
      </div>
      <button onClick={onDelete} className="text-muted-foreground hover:text-red-500 transition-colors flex-shrink-0">
        <Trash2 className="w-4 h-4" />
      </button>
    </div>
  )
}

export default function Clasificacion() {
  const { activeSeason, appUser } = useAppContext()
  const { data: standingsData, loading, trigger: triggerStandings } = useGetStandings()
  const { data: groupsData, trigger: triggerGroups } = useGetGroups()
  const { data: rulesData, trigger: triggerRules } = useGetStandingRules()
  const { trigger: saveRules } = useSaveStandingRules()

  const [activeGroup, setActiveGroup] = useState<number | null>(null)
  const [showRulesEditor, setShowRulesEditor] = useState(false)
  const [editRules, setEditRules] = useState<StandingRule[]>([])

  const groups = (groupsData as (Group & { color?: string })[] | undefined) ?? []
  const standings = (standingsData as Standing[] | undefined) ?? []
  const rules = (rulesData as StandingRule[] | undefined) ?? []
  const canEdit = appUser?.role === 'administrator' || appUser?.role === 'captain'

  useEffect(() => {
    if (!activeSeason) return
    if (activeSeason.has_groups) triggerGroups({ season_id: activeSeason.id })
    triggerStandings({ season_id: activeSeason.id })
    triggerRules({ season_id: activeSeason.id })
    setActiveGroup(null)
  }, [activeSeason?.id])

  useEffect(() => {
    if (!activeSeason || !activeSeason.has_groups) return
    triggerStandings({ season_id: activeSeason.id, ...(activeGroup !== null ? { group_id: activeGroup } : {}) })
  }, [activeGroup])

  function openRulesEditor() {
    setEditRules(rules.length > 0 ? rules.map(r => ({ ...r })) : PRESET_RULES.map(r => ({ ...r })))
    setShowRulesEditor(true)
  }

  async function handleSaveRules() {
    if (!activeSeason) return
    await saveRules({ season_id: activeSeason.id, rules: editRules.map((r, i) => ({ ...r, sort_order: i })) })
    setShowRulesEditor(false)
    triggerRules({ season_id: activeSeason.id })
  }

  return (
    <div className="p-6 max-w-4xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <Trophy className="w-6 h-6 text-yellow-500" />
          <div>
            <h1 className="text-2xl font-bold text-foreground">Clasificación</h1>
            {activeSeason && <p className="text-sm text-muted-foreground">{activeSeason.name}</p>}
          </div>
        </div>
        {canEdit && (
          <Button size="sm" variant="outline" onClick={openRulesEditor}>
            <Settings className="w-4 h-4 mr-1.5" /> Configurar posiciones
          </Button>
        )}
      </div>

      {/* Group tabs */}
      {activeSeason?.has_groups && groups.length > 0 && (
        <div className="flex gap-2 mb-4 flex-wrap">
          <button
            onClick={() => setActiveGroup(null)}
            className={cn('px-4 py-1.5 rounded-full text-sm font-medium transition-colors',
              activeGroup === null ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground hover:text-foreground'
            )}
          >
            Todos
          </button>
          {groups.map(g => (
            <button key={g.id} onClick={() => setActiveGroup(g.id)}
              className={cn('flex items-center gap-2 px-4 py-1.5 rounded-full text-sm font-medium transition-colors',
                activeGroup === g.id ? 'text-white' : 'bg-muted text-muted-foreground hover:text-foreground'
              )}
              style={activeGroup === g.id ? { backgroundColor: g.color ?? '#38bdf8' } : {}}>
              {g.color && <span className="w-2 h-2 rounded-full" style={{ backgroundColor: g.color }} />}
              Grupo {g.name}
            </button>
          ))}
        </div>
      )}

      {/* Standings table */}
      <div className="bg-card border border-border rounded-xl overflow-hidden">
        {loading ? (
          <div className="p-8 text-center text-muted-foreground">Cargando clasificación...</div>
        ) : standings.length === 0 ? (
          <div className="p-8 text-center text-muted-foreground">No hay equipos en esta temporada todavía</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-muted/40 border-b border-border">
                  <th className="w-1 p-0" />
                  <th className="px-4 py-3 text-left text-xs font-semibold text-muted-foreground uppercase tracking-wide w-8">#</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-muted-foreground uppercase tracking-wide">Equipo</th>
                  <th className="px-4 py-3 text-center text-xs font-semibold text-muted-foreground uppercase">PJ</th>
                  <th className="px-4 py-3 text-center text-xs font-semibold text-muted-foreground uppercase">PG</th>
                  <th className="px-4 py-3 text-center text-xs font-semibold text-muted-foreground uppercase">PE</th>
                  <th className="px-4 py-3 text-center text-xs font-semibold text-muted-foreground uppercase">PP</th>
                  <th className="px-4 py-3 text-center text-xs font-semibold text-muted-foreground uppercase">GF</th>
                  <th className="px-4 py-3 text-center text-xs font-semibold text-muted-foreground uppercase">GC</th>
                  <th className="px-4 py-3 text-center text-xs font-semibold text-muted-foreground uppercase">DG</th>
                  <th className="px-4 py-3 text-center text-xs font-semibold text-muted-foreground uppercase">Pts</th>
                </tr>
              </thead>
              <tbody>
                {standings.map((s, i) => {
                  const pos = i + 1
                  const ruleColor = getPositionColor(pos, rules)
                  return (
                    <tr key={s.id} className="border-b border-border/50 hover:bg-muted/20 transition-colors">
                      {/* Position color bar */}
                      <td className="w-1 p-0">
                        <div className="w-1 h-full min-h-[44px]" style={{ backgroundColor: ruleColor ?? 'transparent' }} />
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-1.5">
                          {pos === 1 && <Trophy className="w-3.5 h-3.5 text-yellow-500" />}
                          {pos !== 1 && <span className="text-muted-foreground text-sm">{pos}</span>}
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-3">
                          <div className="w-1.5 h-8 rounded-full flex-shrink-0" style={{ backgroundColor: s.primary_color }} />
                          {s.logo_url
                            ? <img src={s.logo_url} className="w-7 h-7 rounded-full object-cover" alt={s.name} />
                            : <div className="w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold text-white"
                                style={{ backgroundColor: s.primary_color }}>{s.name.slice(0, 1)}</div>
                          }
                          <span className="font-semibold text-foreground">{s.name}</span>
                        </div>
                      </td>
                      <td className="px-4 py-3 text-center text-muted-foreground">{s.played}</td>
                      <td className="px-4 py-3 text-center text-green-600 dark:text-green-400 font-medium">{s.won}</td>
                      <td className="px-4 py-3 text-center text-muted-foreground">{s.drawn}</td>
                      <td className="px-4 py-3 text-center text-red-500 font-medium">{s.lost}</td>
                      <td className="px-4 py-3 text-center text-muted-foreground">{s.goals_for}</td>
                      <td className="px-4 py-3 text-center text-muted-foreground">{s.goals_against}</td>
                      <td className="px-4 py-3 text-center">
                        <div className="flex items-center justify-center gap-1">
                          {s.goal_diff > 0 ? <TrendingUp className="w-3 h-3 text-green-500" />
                            : s.goal_diff < 0 ? <TrendingDown className="w-3 h-3 text-red-500" />
                            : <Minus className="w-3 h-3 text-muted-foreground" />}
                          <span className={cn('font-medium text-sm',
                            s.goal_diff > 0 ? 'text-green-600 dark:text-green-400' :
                            s.goal_diff < 0 ? 'text-red-500' : 'text-muted-foreground')}>
                            {s.goal_diff > 0 ? `+${s.goal_diff}` : s.goal_diff}
                          </span>
                        </div>
                      </td>
                      <td className="px-4 py-3 text-center">
                        <span className="inline-flex items-center justify-center w-8 h-8 rounded-full bg-primary text-primary-foreground font-bold text-sm">
                          {s.points}
                        </span>
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Position legend */}
      {rules.length > 0 && (
        <div className="flex gap-4 mt-4 flex-wrap">
          {rules.map((r, i) => (
            <div key={i} className="flex items-center gap-1.5 text-xs text-muted-foreground">
              <div className="w-3 h-3 rounded-sm" style={{ backgroundColor: r.color }} />
              <span>{r.label} ({r.position_from === r.position_to ? `${r.position_from}º` : `${r.position_from}º–${r.position_to}º`})</span>
            </div>
          ))}
        </div>
      )}

      {/* Legend footer */}
      <div className="mt-3 flex gap-4 text-xs text-muted-foreground flex-wrap">
        {['PJ=Partidos jugados','PG=Ganados','PE=Empatados','PP=Perdidos','GF=Goles favor','GC=Goles contra','DG=Diferencia','Pts=Puntos']
          .map(t => <span key={t}>{t}</span>)}
      </div>

      {/* Rules editor dialog */}
      <Dialog open={showRulesEditor} onOpenChange={setShowRulesEditor}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>Configurar colores de posición</DialogTitle>
          </DialogHeader>
          <p className="text-xs text-muted-foreground -mt-1">Define qué color tendrá cada zona de la tabla (campeón, ascenso, descenso...)</p>
          <div className="mt-2">
            {editRules.map((r, i) => (
              <RuleRow key={i} rule={r}
                onChange={updated => setEditRules(prev => prev.map((x, j) => j === i ? updated : x))}
                onDelete={() => setEditRules(prev => prev.filter((_, j) => j !== i))} />
            ))}
            <button
              onClick={() => setEditRules(prev => [...prev, { position_from: (prev[prev.length - 1]?.position_to ?? 0) + 1, position_to: (prev[prev.length - 1]?.position_to ?? 0) + 1, color: '#6b7280', label: 'Zona' }])}
              className="flex items-center gap-2 mt-3 text-xs text-primary hover:underline">
              <Plus className="w-3.5 h-3.5" /> Añadir zona
            </button>
          </div>
          <div className="flex gap-2 justify-end pt-4 border-t border-border mt-4">
            <Button variant="outline" size="sm" onClick={() => setShowRulesEditor(false)}>Cancelar</Button>
            <Button size="sm" onClick={handleSaveRules}>
              <Check className="w-4 h-4 mr-1" /> Guardar
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
