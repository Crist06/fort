import { useRef, useState } from 'react'
import { Paintbrush, Upload, X, Check, Trash2 } from 'lucide-react'
import { useSaveBackground, useUploadBackground } from '../hooks/backend/users'
import { cn } from '../lib/shadcn/utils'

export const PRESETS = [
  { id: 'default',   label: 'Predeterminado', css: '' },
  { id: 'navy',      label: 'Marino',         css: 'linear-gradient(160deg,#060c1a 0%,#0a1628 60%,#0d1f38 100%)' },
  { id: 'pitch',     label: 'Césped',         css: 'linear-gradient(180deg,#0a1f0f 0%,#1a4731 50%,#0f2d1f 100%)' },
  { id: 'stadium',   label: 'Estadio',        css: 'linear-gradient(180deg,#05080f 0%,#0a0f1e 40%,#141e35 100%)' },
  { id: 'galaxy',    label: 'Galaxia',        css: 'linear-gradient(135deg,#0f0c29 0%,#302b63 50%,#24243e 100%)' },
  { id: 'midnight',  label: 'Medianoche',     css: 'linear-gradient(180deg,#0f0f1a 0%,#1a0a2e 100%)' },
  { id: 'ocean',     label: 'Océano',         css: 'linear-gradient(135deg,#0c1e3c 0%,#1e3a5f 50%,#064e73 100%)' },
  { id: 'aurora',    label: 'Aurora',         css: 'linear-gradient(135deg,#023e1a 0%,#004d40 40%,#01579b 100%)' },
  { id: 'crimson',   label: 'Carmesí',        css: 'linear-gradient(135deg,#0f0606 0%,#2d0a0a 50%,#4c1010 100%)' },
  { id: 'gold',      label: 'Dorado',         css: 'linear-gradient(135deg,#0f0a03 0%,#2d1a00 50%,#4a2e00 100%)' },
  { id: 'steel',     label: 'Acero',          css: 'linear-gradient(180deg,#1a1a2e 0%,#16213e 50%,#0f3460 100%)' },
  { id: 'forest',    label: 'Bosque',         css: 'linear-gradient(180deg,#0a1a0f 0%,#1a4731 60%,#0f2d1f 100%)' },
  { id: 'sunset',    label: 'Atardecer',      css: 'linear-gradient(135deg,#1a0a0f 0%,#4c1030 40%,#7c2d12 100%)' },
  { id: 'violet',    label: 'Violeta',        css: 'linear-gradient(135deg,#0d0618 0%,#1e0a38 50%,#2d1060 100%)' },
  { id: 'slate',     label: 'Pizarra',        css: 'linear-gradient(180deg,#0f172a 0%,#1e293b 100%)' },
  { id: 'dark-mesh', label: 'Rejilla',        css: 'radial-gradient(ellipse at 20% 20%,#1e3a5f 0%,transparent 50%),radial-gradient(ellipse at 80% 80%,#1a1035 0%,transparent 50%),#060c1a' },
]

function isUrl(val: string) {
  return val.startsWith('http') || val.startsWith('data:')
}

function PresetThumb({ preset, active, onClick }: {
  preset: typeof PRESETS[0]; active: boolean; onClick: () => void
}) {
  return (
    <button
      onClick={onClick}
      title={preset.label}
      className={cn(
        'relative w-full aspect-video rounded-lg overflow-hidden transition-all border-2',
        active ? 'border-primary scale-105 shadow-lg shadow-primary/30' : 'border-transparent hover:border-white/20'
      )}
      style={{ background: preset.css || '#1e293b' }}
    >
      {active && (
        <div className="absolute inset-0 flex items-center justify-center bg-black/30">
          <Check className="w-4 h-4 text-white" />
        </div>
      )}
      <span className="absolute bottom-0 inset-x-0 text-[9px] text-center py-0.5 font-medium text-white/70 bg-black/40">
        {preset.label}
      </span>
    </button>
  )
}

interface Props {
  current: string
  onClose: () => void
  onApply: (value: string) => void
}

export function BackgroundPicker({ current, onClose, onApply }: Props) {
  const { trigger: saveBackground } = useSaveBackground()
  const { trigger: uploadBackground } = useUploadBackground()

  const [selected, setSelected] = useState(current)
  const [uploading, setUploading] = useState(false)
  const [saving, setSaving] = useState(false)
  const fileRef = useRef<HTMLInputElement>(null)

  // Immediately preview when selecting
  function pick(value: string) {
    setSelected(value)
    onApply(value) // live preview
  }

  async function handleFileUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0]
    if (!file) return
    if (file.size > 8 * 1024 * 1024) { alert('Imagen demasiado grande (máx 8 MB)'); return }

    setUploading(true)
    try {
      // Resize image client-side to max 1920px
      const resized = await resizeImage(file, 1920)
      const base64 = resized.split(',')[1] ?? ''
      const result = await uploadBackground({ base64, filename: file.name, mimeType: file.type })
      const url = (result as { url: string }).url
      pick(url)
    } catch (err) {
      alert('Error al subir imagen')
    } finally {
      setUploading(false)
    }
  }

  async function handleSave() {
    setSaving(true)
    await saveBackground({ background_value: selected })
    setSaving(false)
    onClose()
  }

  const _activePreset = PRESETS.find(p => p.css === selected || (p.id === 'default' && !selected))
  void _activePreset

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-4" style={{ background: 'rgba(0,0,0,0.75)' }} onClick={onClose}>
      <div className="relative bg-card border border-border rounded-2xl w-full max-w-lg max-h-[90vh] flex flex-col shadow-2xl"
        onClick={e => e.stopPropagation()}>

        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-border flex-shrink-0">
          <div className="flex items-center gap-2">
            <Paintbrush className="w-5 h-5 text-primary" />
            <h2 className="font-bold text-foreground">Personalizar Fondo</h2>
          </div>
          <button onClick={onClose} className="text-muted-foreground hover:text-foreground transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-5 space-y-5">

          {/* Upload custom */}
          <div>
            <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-3">Fondo Personalizado</p>
            <div className="flex gap-3">
              <button
                onClick={() => fileRef.current?.click()}
                disabled={uploading}
                className="flex-1 flex flex-col items-center justify-center gap-2 border-2 border-dashed border-border rounded-xl py-5 hover:border-primary/50 transition-colors"
              >
                {uploading
                  ? <div className="w-5 h-5 border-2 border-primary border-t-transparent rounded-full animate-spin" />
                  : <Upload className="w-5 h-5 text-muted-foreground" />
                }
                <span className="text-xs text-muted-foreground">{uploading ? 'Subiendo...' : 'Subir imagen'}</span>
                <span className="text-[10px] text-muted-foreground/60">PNG, JPG, WebP · máx 8 MB</span>
              </button>
              {isUrl(selected) && (
                <div className="relative w-24 h-full min-h-[80px] rounded-xl overflow-hidden border border-border flex-shrink-0">
                  <img src={selected} className="w-full h-full object-cover" alt="custom bg" />
                  <button
                    onClick={() => pick('')}
                    className="absolute top-1 right-1 bg-black/60 rounded-full p-0.5 text-white hover:bg-red-500 transition-colors"
                  >
                    <X className="w-3 h-3" />
                  </button>
                  <div className="absolute bottom-0 inset-x-0 bg-black/50 py-1 text-center text-[9px] text-white/80">
                    Actual
                  </div>
                </div>
              )}
            </div>
            <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={handleFileUpload} />
          </div>

          {/* Presets */}
          <div>
            <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-3">Predefinidos</p>
            <div className="grid grid-cols-4 gap-2">
              {PRESETS.map(p => (
                <PresetThumb
                  key={p.id}
                  preset={p}
                  active={p.id === 'default' ? !selected || selected === p.css : selected === p.css}
                  onClick={() => pick(p.css)}
                />
              ))}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between px-5 py-4 border-t border-border flex-shrink-0">
          <button onClick={() => pick('')} className="flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground transition-colors">
            <Trash2 className="w-3.5 h-3.5" /> Quitar fondo
          </button>
          <div className="flex gap-2">
            <button onClick={onClose} className="px-4 py-1.5 rounded-lg text-sm border border-border text-muted-foreground hover:text-foreground transition-colors">
              Cancelar
            </button>
            <button onClick={handleSave} disabled={saving}
              className="flex items-center gap-1.5 px-4 py-1.5 rounded-lg text-sm font-medium bg-primary text-primary-foreground hover:bg-primary/90 transition-colors disabled:opacity-50">
              {saving ? 'Guardando...' : <><Check className="w-4 h-4" /> Guardar</>}
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}

// Resize image to maxWidth using canvas
async function resizeImage(file: File, maxWidth: number): Promise<string> {
  return new Promise((resolve, reject) => {
    const img = new Image()
    const url = URL.createObjectURL(file)
    img.onload = () => {
      const scale = Math.min(1, maxWidth / img.width)
      const canvas = document.createElement('canvas')
      canvas.width = Math.round(img.width * scale)
      canvas.height = Math.round(img.height * scale)
      const ctx = canvas.getContext('2d')
      if (!ctx) { reject(new Error('canvas error')); return }
      ctx.drawImage(img, 0, 0, canvas.width, canvas.height)
      URL.revokeObjectURL(url)
      resolve(canvas.toDataURL(file.type.includes('png') ? 'image/png' : 'image/jpeg', 0.85))
    }
    img.onerror = () => reject(new Error('load error'))
    img.src = url
  })
}
