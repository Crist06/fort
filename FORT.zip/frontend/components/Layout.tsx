import { useState } from 'react'
import { Link, useLocation } from 'react-router-dom'
import {
  Trophy, BarChart3, Calendar, ShoppingBag,
  Settings, Menu, X,
  Star, Shield, Home, Swords, Paintbrush
} from 'lucide-react'
import { useAppContext } from '../context/AppContext'
import { cn } from '../lib/shadcn/utils'
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue
} from '../lib/shadcn/select'
import { BackgroundPicker } from './BackgroundPicker'
import type { Season } from '../types'

const ROLE_LABELS: Record<string, string> = {
  player: 'Jugador',
  captain: 'Capitán',
  referee: 'Árbitro',
  administrator: 'Administrador',
}

const ROLE_COLORS: Record<string, string> = {
  player: 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200',
  captain: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200',
  referee: 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200',
  administrator: 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200',
}

interface NavItem {
  to: string
  label: string
  icon: React.ReactNode
  roles?: string[]
  requiresPlayer?: boolean
}

const NAV_ITEMS: NavItem[] = [
  { to: '/', label: 'Inicio', icon: <Home className="w-5 h-5" /> },
  { to: '/clasificacion', label: 'Clasificación', icon: <Trophy className="w-5 h-5" /> },
  { to: '/estadisticas', label: 'Estadísticas', icon: <BarChart3 className="w-5 h-5" /> },
  { to: '/equipos', label: 'Equipos', icon: <Shield className="w-5 h-5" /> },
  { to: '/partidos', label: 'Jornada', icon: <Swords className="w-5 h-5" /> },
  { to: '/mis-partidos', label: 'Mis Partidos', icon: <Star className="w-5 h-5" />, requiresPlayer: true },
  { to: '/mercado', label: 'Mercado', icon: <ShoppingBag className="w-5 h-5" /> },
]

const ADMIN_NAV_ITEMS: NavItem[] = [
  { to: '/temporadas', label: 'Temporadas', icon: <Calendar className="w-5 h-5" />, roles: ['administrator'] },
  { to: '/admin', label: 'Panel Admin', icon: <Settings className="w-5 h-5" />, roles: ['administrator'] },
]

function SeasonSelect() {
  const { activeSeason, seasons, setActiveSeason } = useAppContext()
  if (!seasons.length) return null

  return (
    <Select
      value={activeSeason?.id.toString() ?? ''}
      onValueChange={(val: string) => {
        const s = seasons.find(s => s.id.toString() === val)
        if (s) setActiveSeason(s as Season)
      }}
    >
      <SelectTrigger className="h-8 text-xs bg-background border-border w-40">
        <SelectValue placeholder="Temporada" />
      </SelectTrigger>
      <SelectContent>
        {seasons.map(s => (
          <SelectItem key={s.id} value={s.id.toString()}>
            {s.name}
            {s.status === 'active' && <span className="ml-1 text-green-500">●</span>}
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  )
}

export default function Layout({ children }: { children: React.ReactNode }) {
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [showBgPicker, setShowBgPicker] = useState(false)
  const { appUser, background, setBackground } = useAppContext()
  const location = useLocation()

  const role = appUser?.role ?? ''
  const hasPlayer = !!appUser?.player_id

  const visibleNav = NAV_ITEMS.filter(item => {
    if (item.requiresPlayer && !hasPlayer) return false
    if (item.roles && !item.roles.includes(role)) return false
    return true
  })

  const visibleAdmin = ADMIN_NAV_ITEMS.filter(item =>
    !item.roles || item.roles.includes(role)
  )

  const displayName = appUser?.nickname ?? appUser?.username ?? '...'
  const initials = displayName.slice(0, 2).toUpperCase()

  function NavLinks({ onClick }: { onClick?: () => void }) {
    return (
      <>
        <nav className="flex-1 px-2 py-4 space-y-1">
          {visibleNav.map(item => (
            <Link
              key={item.to}
              to={item.to}
              onClick={onClick}
              className={cn(
                'flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors',
                location.pathname === item.to
                  ? 'bg-primary text-primary-foreground'
                  : 'text-muted-foreground hover:text-foreground hover:bg-accent'
              )}
            >
              {item.icon}
              {item.label}
            </Link>
          ))}
        </nav>
        {visibleAdmin.length > 0 && (
          <div className="px-2 pb-4">
            <p className="px-3 text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">
              Administración
            </p>
            {visibleAdmin.map(item => (
              <Link
                key={item.to}
                to={item.to}
                onClick={onClick}
                className={cn(
                  'flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors',
                  location.pathname === item.to
                    ? 'bg-primary text-primary-foreground'
                    : 'text-muted-foreground hover:text-foreground hover:bg-accent'
                )}
              >
                {item.icon}
                {item.label}
              </Link>
            ))}
          </div>
        )}
        {/* User footer */}
        <div className="px-4 pb-4 border-t border-border pt-3">
          <Link to="/perfil" onClick={onClick} className="flex items-center gap-3 group">
            <div className="w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-xs font-bold flex-shrink-0">
              {appUser?.photo_url
                ? <img src={appUser.photo_url} className="w-8 h-8 rounded-full object-cover" alt="" />
                : initials
              }
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-foreground truncate">{displayName}</p>
              {appUser?.role && (
                <span className={cn('text-xs px-1.5 py-0.5 rounded font-medium', ROLE_COLORS[role])}>
                  {ROLE_LABELS[role]}
                </span>
              )}
            </div>
          </Link>
        </div>
      </>
    )
  }

  return (
    <div className="flex h-screen overflow-hidden" style={{ background: 'transparent' }}>
      {/* Global background layer */}
      {background && (
        <div
          className="fixed inset-0 -z-10"
          style={background.startsWith('http') || background.startsWith('data:')
            ? { backgroundImage: `url(${background})`, backgroundSize: 'cover', backgroundPosition: 'center', backgroundRepeat: 'no-repeat' }
            : { background }
          }
        />
      )}
      {/* Desktop sidebar */}
      <aside className="hidden lg:flex flex-col w-56 border-r border-border bg-card flex-shrink-0">
        <div className="flex items-center gap-2 px-4 h-14 border-b border-border">
          <div className="w-7 h-7 bg-primary rounded-lg flex items-center justify-center">
            <Trophy className="w-4 h-4 text-primary-foreground" />
          </div>
          <span className="font-bold text-foreground">FútbolApp</span>
        </div>
        <NavLinks />
      </aside>

      {/* Mobile sidebar overlay */}
      {sidebarOpen && (
        <div className="lg:hidden fixed inset-0 z-50 flex">
          <div className="fixed inset-0 bg-black/50" onClick={() => setSidebarOpen(false)} />
          <aside className="relative flex flex-col w-64 bg-card border-r border-border z-50">
            <div className="flex items-center justify-between px-4 h-14 border-b border-border">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 bg-primary rounded-lg flex items-center justify-center">
                  <Trophy className="w-4 h-4 text-primary-foreground" />
                </div>
                <span className="font-bold text-foreground">FútbolApp</span>
              </div>
              <button onClick={() => setSidebarOpen(false)} className="text-muted-foreground">
                <X className="w-5 h-5" />
              </button>
            </div>
            <NavLinks onClick={() => setSidebarOpen(false)} />
          </aside>
        </div>
      )}

      {/* Main content */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Header */}
        <header className="flex items-center justify-between px-4 h-14 border-b border-border bg-card flex-shrink-0">
          <button
            className="lg:hidden text-muted-foreground hover:text-foreground"
            onClick={() => setSidebarOpen(true)}
          >
            <Menu className="w-5 h-5" />
          </button>
          <div className="flex-1 lg:flex-none" />
          <div className="flex items-center gap-3">
            <SeasonSelect />
            {/* Background picker trigger */}
            <button
              onClick={() => setShowBgPicker(true)}
              title="Personalizar fondo"
              className="hidden sm:flex text-muted-foreground hover:text-foreground transition-colors"
            >
              <Paintbrush className="w-4 h-4" />
            </button>
            <Link to="/perfil" className="hidden sm:flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground">
              <div className="w-7 h-7 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-xs font-bold">
                {appUser?.photo_url
                  ? <img src={appUser.photo_url} className="w-7 h-7 rounded-full object-cover" alt="" />
                  : initials
                }
              </div>
            </Link>
          </div>
        </header>

        {/* Page content */}
        <main className="flex-1 overflow-y-auto">
          {children}
        </main>
      </div>

      {/* Background picker */}
      {showBgPicker && (
        <BackgroundPicker
          current={background}
          onClose={() => setShowBgPicker(false)}
          onApply={setBackground}
        />
      )}
    </div>
  )
}
